# UMAN EVENT MANAGER — PHASE 1 HANDOFF

## Authoritative frozen baseline

Read these before writing code:

1. Master Product & System Specification v2.4: UMAN_EVENT_MANAGER_SPEC_v2.3.md — authoritative product/domain baseline; status IMPLEMENTATION BASELINE — OPEN PRODUCT DECISIONS EXPLICITLY DEFERRED.
2. Technical Architecture & Implementation Specification v1.1: UMAN_EVENT_MANAGER_TECH_SPEC_v1.0.md — authoritative technical baseline where it does not contradict the Master.
3. The spec_parts/part*.md files are maintained sectional copies of the Master. Do not create a competing specification.

`UMAN_MNGMNT.zip` is a historical packaging artifact that predates this freeze and is not authoritative. Use the root documents above; regenerate the archive only as a deliberate release-packaging step after implementation work.

## Phase 1 scope

Implement only offline, single-device Android/iOS foundations: 19 persistent entities, encrypted Drift persistence, repositories/use cases, pure-Dart rules, unresolved-state persistence, BLoC scaffolding, event-scoped search/export, plain-text sharing snapshots, backup/restore, and tests. Do not build cloud/sync/RBAC, PDF/HTML reports, global people, attachment storage, or finance allocation.

## Non-negotiable architecture

- lib/domain/ is pure Dart: no Flutter, Drift, filesystem, SQL, or platform imports.
- Every normal persistent ID is UUIDv4. UnresolvedItem.id is sha256(ruleCode|entityType|entityId|scopeKey); random derived-alert IDs are forbidden.
- Pair/multi-entity scope keys use sorted IDs joined by |.
- Rules receive small immutable rule-specific snapshots from indexed event-scoped queries. Never load all tables/an event after ordinary CRUD. Immediate critical evaluation and 300ms coalesced related edits are required; full evaluation is only integrity/recovery/manual audit/refresh.
- Preserve manager source data. Rules detect, warn, and change only derived unresolved state.
- Person.passport_expiration_date is nullable and mandatory in domain/schema mapping for PASSPORT_EXPIRY_RISK.
- Vehicle capacity alert means activePassengerCount > capacity; exactly at capacity is valid.
- Canonical code is ACCOMMODATION_OVERLAP; never use ACC_OVERLAP or forbidden aliases in Technical Spec §2.1.

## Selected persistence/security path

- Use Drift 2.32+, sqlite3 3.x, NativeDatabase.createInBackground, and SQLite3MultipleCiphers via sqlite3 build hook source sqlite3mc.
- Do not add drift_sqflite, sqflite_sqlcipher, encrypted_drift, sqlcipher_flutter_libs, or sqlite3_flutter_libs.
- Cipher availability is a runtime guard before write; no plaintext fallback. One keyed database owner only.
- PBKDF2-HMAC-SHA256: 600,000 iterations, random 16-byte salt, 32-byte key. Never store passphrases or raw keys in preferences/logs. Derived DB key is session-memory only; secure storage holds non-secret KDF metadata/configuration.
- Backups use AES-256-GCM authenticated envelopes. Authenticate before decryption/extraction; restore only in isolated temp workspace with Zip-Slip rejection, integrity/schema validation, confirmation, pre-restore backup, atomic replacement, and reopening verification.

## UI/output

Use BLoC, centralized BidiTextFormatter, logical Start/End layout, RTL/LTR and mixed Hebrew/English support, high contrast, 48dp targets, and non-color-only severity. MVP sharing is timestamped static bilingual plain text for copy/share/WhatsApp with PII masking default-on. Structured export is event-scoped CSV/JSON. PDF/HTML reports are Phase 2.

## Required validation

Before Phase 1 is complete: pure domain ID/lifecycle tests (including order-independent pairs and acknowledgment preservation), event isolation/scoped repository tests, Android/iOS encrypted-open/migration integration, backup tamper/wrong-passphrase/Zip-Slip/atomic restore tests, AC-01–AC-12, BIDI/widget tests, and benchmark tests.

## Product Owner decisions that must not be invented

OPD-002/003 remain open: expense allocation, participant share, and final per-person unpaid-balance semantics. Persist/reproduce individual Expense/Payment conversions and show non-allocated event totals only. UNPAID_BALANCE is a reserved inactive rule: do not evaluate or display it. Automatic lifecycle-transition thresholds are also undefined; expose manager-authorized transitions only.
