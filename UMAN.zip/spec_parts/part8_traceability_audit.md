## SECTION 37: Requirement Traceability

Provide a compact traceability matrix connecting:
Requirement → Domain/Entity → Rule or Behavior → Acceptance Criterion

Format as a table:

| Req ID | Requirement | Domain | Entity/Entities | Rule/Behavior | Acceptance Criterion |
|---|---|---|---|---|---|
| REQ-001 | Manager sovereignty — no silent changes | All | All | All write operations require explicit manager action | AC-02, AC-03 |
| REQ-002 | Event isolation | Core | Event, All | Event-scoped queries, no cross-event leakage | AC-10 |
| REQ-003 | Offline operation | Architecture | All | No network dependency for any MVP feature | AC-08 |
| REQ-004 | Source data preservation | Data Integrity | All source entities | Original values never overwritten by derived values | AC-04 |
| REQ-005 | Accommodation overlap detection | Accommodation | AccommodationAssignment, SleepingPlace | ACCOMMODATION_OVERLAP rule | AC-01 |
| REQ-006 | Transport capacity enforcement | Transport | Trip, TripPassenger, Vehicle | VEHICLE_OVER_CAPACITY rule | AC-02 |
| REQ-007 | Flight changes don't alter transport | Flight/Transport | Flight, Trip | FLIGHT_DELAY_IMPACT advisory only | AC-03 |
| REQ-008 | Financial reproducibility | Finance | Expense, Payment | Original amounts + rates preserved | AC-04 |
| REQ-009 | Overdue task detection | Tasks | Task | OVERDUE_TASK rule | AC-05 |
| REQ-010 | Soft delete safety | Data Integrity | All deletable entities | is_deleted + restore capability | AC-06 |
| REQ-011 | Backup integrity | Recovery | Backup/Restore | Corrupted backup rejected, DB intact | AC-07 |
| REQ-012 | Bilingual support | UX | All UI | RTL/LTR switching, data preservation | AC-09 |
| REQ-013 | Data migration safety | Migration | Schema | Pre-migration backup, rollback on failure | AC-11 |
| REQ-014 | Crash recovery | Recovery | Database | Transaction atomicity, no partial state | AC-12 |
| REQ-015 | No silent data loss | Data Integrity | All | Destructive actions explicit, confirmations required | AC-06 |
| REQ-016 | Missing info ≠ negative fact | UX/Domain | Person, Flight, etc. | Null fields displayed as 'Not entered', not 'None' | AC-09 |
| REQ-017 | Manager overrides (is_locked) | All lockable | Expense, Payment, AccommodationAssignment, Trip, Flight | is_locked prevents auto-recalculation | AC-04 |
| REQ-018 | Idempotent rule evaluation | Rules Engine | UnresolvedItem | No duplicate active alerts | AC-01, AC-02 |
| REQ-019 | Deterministic derived state | Rules Engine | All derived | Same inputs → same outputs | AC-01-AC-12 |
| REQ-020 | UUIDv4 identities | Architecture | All persistent entities | Sync-ready identifiers | AC-10 |
| REQ-021 | UTC timestamps | Architecture | All temporal fields | No timezone ambiguity | AC-04, AC-05 |
| REQ-022 | Encrypted storage | Security | Database | AES-256 equivalent at rest | AC-08 |
| REQ-023 | Multi-currency support | Finance | Expense, Payment | Original currency preserved, base conversion tracked | AC-04 |
| REQ-024 | Accommodation date semantics | Accommodation | AccommodationAssignment | Start inclusive, end exclusive | AC-01 |
| REQ-025 | Person-SleepingPlace via assignment | Accommodation | SleepingPlace, AccommodationAssignment | No Bed.occupant_id | AC-01 |
| REQ-026 | Trip-Person via TripPassenger | Transport | Trip, TripPassenger | No Trip.person_id | AC-02 |
| REQ-027 | Driver-Vehicle not permanent | Transport | Driver, Vehicle, Trip | Driver assigned per-trip, not per-vehicle | AC-02 |
| REQ-028 | UnresolvedItem is derived | Rules Engine | UnresolvedItem | Auto-resolves when source condition clears | AC-01, AC-02, AC-05 |
| REQ-029 | Audit readiness | Audit | AuditEntry | Structural support for change tracking | AC-06 |
| REQ-030 | Performance benchmarks | Performance | All | Measurable targets on benchmark dataset | Performance section |
| REQ-031 | Deterministic Alert Identity | Rules Engine | UnresolvedItem | SHA-256 canonical hash identity; idempotent evaluations | AC-01, AC-02 |
| REQ-032 | Scoped Rule Evaluation & Hybrid Scheduling | Rules Engine | DomainRule | Scoped queries; debounced/immediate hybrid scheduling | Performance section |
| REQ-033 | Future-proof Database Metadata | Architecture | Persistent entities | `deleted_at_utc`, `version`, `last_modified_by_device_id` added | AC-11 |
| REQ-034 | KDF Key Derivation & Platform Secure Storage | Security | SecurityKeyService, SecurityStorageService | PBKDF2-HMAC-SHA256 256-bit key; Keystore/Keychain metadata storage | AC-08 |
| REQ-035 | AEAD Backup Authenticated Envelope | Recovery | Backup/Restore | AEAD header authentication before extraction; Zip-Slip isolation | AC-07 |
| REQ-036 | External Sharing Snapshot PII Sanitization | UX / Sharing | Snapshot Exporter | Default PII masking ON; explicit unmasked export warning | AC-09 |
| REQ-037 | Centralized BIDI Text Isolation | UX | Presentation | `BidiTextFormatter` helper for mixed Hebrew/English strings | AC-09 |
| REQ-038 | Operational Alert Triage & Outdoor UX | Presentation | Control Center | Grouping, severity filters, direct action deep-links, high-contrast theme | AC-05 |

### Canonical Rule Test Coverage

Every active code in Section 18 requires a pure-domain positive, negative, deterministic-ID, and lifecycle test. The acceptance scenarios remain the end-to-end anchors: AC-01 (`ACCOMMODATION_OVERLAP`, sleeping-place coverage), AC-02 (`VEHICLE_OVER_CAPACITY`), AC-03 (`FLIGHT_DELAY_IMPACT`), AC-05 (`OVERDUE_TASK`), and AC-06 (orphan/restore impacts). The remaining active codes require focused domain tests in Phase 1; `UNPAID_BALANCE` is explicitly excluded because it is inactive pending OPD-002/003. `EVENT_LIFECYCLE_TRANSITION_NEEDED` must not emit automatically until its Product Owner criteria exist.

## SECTION 38: Definition of Done

The Master Specification is COMPLETE only when ALL of the following are true:

| # | Criterion | Status |
|---|---|---|
| 1 | MVP boundaries are explicit | ✅ Defined in Section 6 |
| 2 | Future features explicitly separated | ✅ Defined in Section 6, 28, 29 |
| 3 | Every major entity defined | ✅ Section 34 — 19 entities |
| 4 | Every relationship has defined cardinality | ✅ Section 34 |
| 5 | Event isolation defined | ✅ Sections 7, 34, AC-10 |
| 6 | Source and derived state separated | ✅ Section 5, 34 |
| 7 | Manager authority preserved | ✅ Section 5, all domain sections |
| 8 | Manager overrides defined | ✅ Section 5, 14, 16, 34 |
| 9 | Delete/archive/cancel/unassign/resolve/restore semantics | ✅ Section 24 |
| 10 | Individual financial conversions reproducible; allocation explicitly deferred | ✅ Section 16 |
| 11 | Accommodation date semantics defined | ✅ Section 14 |
| 12 | Transport passenger relationships defined | ✅ Section 13, 34 |
| 13 | Driver and vehicle relationships defined | ✅ Sections 11, 12, 13, 34 |
| 14 | Flight changes cannot silently rewrite transport | ✅ Sections 10, 13, 35 |
| 15 | Rules deterministic, scoped, idempotent | ✅ Section 18 |
| 16 | Unresolved item deduplication defined | ✅ Section 19 |
| 17 | Offline behavior defined | ✅ Section 27 |
| 18 | Crash recovery defined | ✅ Section 25, 35 |
| 19 | Backup/restore safety defined | ✅ Section 25, AC-07 |
| 20 | Migration safety defined | ✅ Section 32, AC-11 |
| 21 | Security outcomes defined | ✅ Section 26 |
| 22 | Future sync constraints defined (not implemented) | ✅ Section 28 |
| 23 | Future permissions constraints defined (not implemented) | ✅ Section 29 |
| 24 | Performance targets measurable | ✅ Section 33 |
| 25 | Hebrew/English behavior defined | ✅ Section 22 |
| 26 | RTL/LTR behavior defined | ✅ Section 22 |
| 27 | Sharing behavior defined | ✅ Section 23 |
| 28 | Uman-specific edge cases covered | ✅ Section 35 |
| 29 | Acceptance tests cover critical workflows | ✅ Section 36 — 12 scenarios |
| 30 | Requirement traceability exists | ✅ Section 37 |
| 31 | No unresolved contradiction hidden | ✅ Section 40 |

## SECTION 39: Open Decisions & Explicitly Deferred Items

### Open Product Decisions

| ID | Decision | Impact | Interim MVP Behavior | Resolution Needed By |
|---|---|---|---|---|
| OPD-002 | Expense allocation model: equal split, custom per-person, or per-expense assignment | Balance calculation accuracy | No allocation, participant share, or `UNPAID_BALANCE` evaluation is implemented; only individual conversions and non-allocated event totals | Before financial feature completion |
| OPD-003 | Participant share calculation and final unpaid-balance semantics | Financial balance correctness | No formula or alert is implemented; `UNPAID_BALANCE` remains inactive | Before financial feature completion |

### Technical Decisions Finalized

Technical choices formerly recorded as OTD-001 through OTD-010 are resolved by Technical Specification v1.1: Drift-native SQLite3MultipleCiphers executor, BLoC, PBKDF2-HMAC-SHA256, FTS5, AES-256-GCM backup envelope, Drift migrations, specified tests, plaintext sharing snapshots, and scoped hybrid rule scheduling. Dependency resolution must pin compatible current package versions and release-test the selected cipher/FTS5 build; this is verification work, not an open architecture decision.

### Explicitly Deferred MVP Features

| ID | Feature | Reason | Phase |
|---|---|---|---|
| DEF-001 | Cloud backend | MVP is offline-first single device | Phase 2 |
| DEF-002 | Multi-user synchronization | Requires cloud infrastructure | Phase 2 |
| DEF-003 | Remote authentication | No cloud in MVP | Phase 2 |
| DEF-004 | RBAC / permissions UI | Single manager in MVP | Phase 2 |
| DEF-005 | Conflict resolution UI | No sync in MVP | Phase 2 |
| DEF-006 | Meals / food management | Out of core scope | Phase 3+ |
| DEF-007 | Automated flight tracking API | MVP is manual/imported flight data | Phase 2 |
| DEF-008 | Automated exchange rate import | MVP uses manual rates | Phase 2 |
| DEF-009 | Push notifications | No server infrastructure | Phase 2 |
| DEF-010 | App lock / biometric authentication | Defer to OS security | Phase 2 |
| DEF-011 | Comprehensive audit log viewer | Structural readiness only in MVP | Phase 2 |
| DEF-012 | Report generation (PDF) | Plain text snapshots in MVP | Phase 2 |
| DEF-013 | Global person directory | Event-scoped persons in MVP | Phase 2 |
| DEF-014 | Automated shopping / food purchasing | Out of scope | Phase 3+ |
| DEF-015 | Event templates | Nice-to-have, not MVP critical | Phase 2 |

## SECTION 40: Final Internal Consistency Audit

### Scope Audit
- ✅ Every feature classified as MVP, Future, or Open Decision
- ✅ No feature exists without classification
- ✅ Shared architectural constraints identified separately

### Entity Audit
- ✅ 19 entities defined with complete field lists
- ✅ All relationships reference valid entities
- ✅ All cardinalities logically coherent
- ✅ No circular dependencies
- ✅ Event ownership path defined for every entity

### Lifecycle Audit
- ✅ Create/edit/delete/archive/cancel/unassign/resolve/restore semantics defined (Section 24)
- ✅ No contradictions between lifecycle operations
- ✅ Soft delete preserves records
- ✅ Restore reverses soft delete

### Financial Audit
- ✅ Original transaction amounts preserved (Section 16)
- ✅ Derived base amounts clearly marked
- ✅ Exchange rates preserved with source and timestamp
- ✅ is_locked prevents auto-recalculation
- ✅ Original amounts and individual conversions are reproducible; allocation and unpaid balance are explicitly deferred (OPD-002/003)

### Accommodation Audit
- ✅ SleepingPlace and AccommodationAssignment are separate entities
- ✅ No Bed.occupant_id pattern
- ✅ Date semantics: start inclusive, end exclusive
- ✅ Same-day turnover explicitly handled
- ✅ Overlap detection defined

### Transport Audit
- ✅ Trip and TripPassenger are separate entities
- ✅ No Trip.person_id pattern
- ✅ Driver and Vehicle are separate entities
- ✅ No permanent Vehicle→Driver binding
- ✅ Capacity validation defined

### Flight Audit
- ✅ Flight changes generate alerts, NOT auto-changes to transport
- ✅ Flight is source data
- ✅ System is not an authoritative flight tracker

### Rules Audit
- ✅ Rules produce derived state only
- ✅ Rules are deterministic and idempotent
- ✅ Stable identity prevents duplicate alerts
- ✅ Auto-resolution when source condition clears

### Alert Audit
- ✅ UnresolvedItem is NOT source data
- ✅ Duplicate active alerts prevented by (rule_code, entity_type, entity_id, scope_key)
- ✅ Lifecycle: DETECTED → ACKNOWLEDGED → RESOLVED/DISMISSED

### Manager Authority Audit
- ✅ No automated process silently overrides manager decisions
- ✅ is_locked semantics defined
- ✅ All consequential changes require explicit manager action

### Offline Audit
- ✅ No MVP feature depends on network connectivity
- ✅ Architecture layers enforce separation
- ✅ Repository abstraction supports future remote sources

### Recovery Audit
- ✅ Crash recovery: transaction atomicity
- ✅ Backup: encrypted, integrity-checked
- ✅ Restore: atomic replacement, pre-restore backup, failure safety
- ✅ Migration: pre-migration backup, failure recovery
- ✅ Corruption: detection and restore path

### Security Audit
- ✅ Encrypted storage at rest
- ✅ No PII in logs
- ✅ No telemetry in MVP
- ✅ No unnecessary network transmission
- ✅ Passphrase protection defined

### Future Architecture Audit
- ✅ Sync constraints defined without implementation (Section 28)
- ✅ Permission constraints defined without implementation (Section 29)
- ✅ No CRDT, Event Sourcing, or distributed state in MVP
- ✅ UUIDv4, UTC timestamps, soft-delete, repository abstraction in place

### Performance Audit
- ✅ Benchmark dataset defined
- ✅ Measurable targets defined
- ✅ No requirement forces full-dataset processing
- ✅ Measurement methodology defined

### Bilingual Audit
- ✅ Hebrew RTL and English LTR defined
- ✅ Logical layout (Start/End) not hard-coded Left/Right
- ✅ Language change never alters source data
- ✅ Mixed-direction content handled

### Traceability Audit
- ✅ 38 requirements mapped to domains, entities, rules, and acceptance criteria; canonical rule coverage requirement added
- ✅ 12 acceptance test scenarios cover critical workflows
- ✅ No orphan requirements or rules identified

### Contradiction Check
- ✅ Pre-implementation freeze repairs applied: canonical fields, rule names, deterministic lifecycle, scoped evaluation, sharing boundary, finance deferral, and event-scoped rule configuration
- ✅ Only genuine Product Owner decisions remain open; no technical architecture decisions remain open

**AUDIT RESULT: IMPLEMENTATION BASELINE — ready for Phase 1 subject to the explicit Product Owner deferrals.**
