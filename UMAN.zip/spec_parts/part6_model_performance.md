## SECTION 33: Performance Requirements & Benchmark Methodology

Benchmark dataset:
- 1,000 participants
- 50 flights with 1,200 flight-passenger records
- 500 trips with 2,500 trip-passenger records
- 30 apartments, 120 rooms, 400 sleeping places
- 1,200 accommodation assignments
- 300 tasks
- 80 apartment issues
- 2,000 expense records
- 1,500 payment records
- 200 active unresolved items
- 20 drivers, 15 vehicles

Target performance benchmarks:
| Operation | Cold | Warm | Target |
|---|---|---|---|
| App launch to interactive | First launch | - | < 1.5s |
| App launch to interactive | Subsequent | - | < 800ms |
| Control Center render | - | Data cached | < 100ms |
| Control Center render | - | Fresh query | < 300ms |
| Universal search (typed query) | - | - | < 80ms per keystroke |
| Entity list render (100 items) | - | - | < 50ms |
| Entity list scroll (infinite) | - | - | 60fps |
| Single entity CRUD | - | - | < 50ms |
| Rule evaluation (single domain) | - | - | < 30ms |
| Rule evaluation (full event) | - | - | < 200ms |
| Backup preparation | - | - | < 5s |
| Backup write | - | - | Proportional to data size |

Representative test device: Mid-range Android device (e.g., Samsung Galaxy A-series, 2023+) with 4GB RAM.

Measurement methodology:
- Cold launch: app process killed, measurement from tap to interactive UI
- Warm launch: app in background, measurement from foreground to interactive
- All measurements on benchmark dataset
- 10 measurements, report p50 and p95
- Acceptable variance: ±20%
- Regression threshold: >30% degradation from baseline triggers investigation

Performance principles:
- No unnecessary full-table scans
- No repeated identical queries within single operation
- No loading entire datasets into memory
- No evaluating unrelated domains during rule checks
- Lazy loading for lists
- Indexed search columns
- Batch operations where appropriate

## SECTION 34: Conceptual Data Model & Relationship Schema

Present the COMPLETE conceptual data model.

> [!NOTE]
> All persistent entities include standard infrastructure metadata columns: `deleted_at_utc` (DATETIME, nullable), `version` (INT, default 1), and `last_modified_by_device_id` (TEXT, nullable). These fields represent future synchronization infrastructure and do NOT execute active synchronization behavior in Phase 1.

For EACH entity, document:
- Purpose (1-2 sentences)
- Fields (name, type, source/derived classification, nullable, constraints)
- Relationships (to which entities, cardinality, FK)
- Lifecycle (creation, modification, deletion, archival)
- Event ownership (direct via event_id, or indirect through parent)
- Validation rules
- Integrity constraints

Entities:

### 1. Event
Root container. All operational data scoped to one event.
- Fields: id (UUID, PK), name (TEXT, required), hebrew_name (TEXT), description (TEXT), year (INT), start_date (DATE), end_date (DATE), base_currency (TEXT, ISO 4217, required), lifecycle_stage (ENUM, required), manager_notes (TEXT), settings_json (TEXT), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Relationships: parent of all event-scoped entities
- Event ownership: self
- Lifecycle: Create → lifecycle transitions → Archive

### 2. Person
An individual participating in an event.
- Fields: id (UUID, PK), event_id (UUID, FK→Event, required), first_name (TEXT, required), last_name (TEXT), hebrew_first_name (TEXT), hebrew_last_name (TEXT), phone (TEXT), whatsapp_phone (TEXT), email (TEXT), passport_name (TEXT), passport_number (TEXT), passport_expiration_date (DATE, nullable), date_of_birth (DATE), nationality (TEXT), emergency_contact_name (TEXT), emergency_contact_phone (TEXT), notes (TEXT), custom_fields_json (TEXT), status (ENUM: ACTIVE/INACTIVE, default ACTIVE), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Relationships: →FlightPassenger(1:N), →TripPassenger(1:N), →AccommodationAssignment(1:N), →Task.assignee(1:N), →ApartmentIssue.reporter(1:N), →Expense.payer(1:N), →Payment(1:N)
- Event ownership: direct (event_id)
- Validation: first_name required, event_id required

### 3. Driver
A person who drives transport vehicles (separate from Person entity).
- Fields: id (UUID, PK), event_id (UUID, FK→Event), name (TEXT, required), phone (TEXT), whatsapp_phone (TEXT), license_info (TEXT), notes (TEXT), status (ENUM: AVAILABLE/BUSY/UNAVAILABLE/OFF_DUTY), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Relationships: →Trip.driver_id(1:N)
- Event ownership: direct

### 4. Flight
A scheduled or actual flight movement.
- Fields: id (UUID, PK), event_id (UUID, FK→Event), direction (ENUM: INBOUND/OUTBOUND), airline (TEXT), flight_number (TEXT), departure_airport (TEXT), arrival_airport (TEXT), scheduled_departure_utc (DATETIME), scheduled_arrival_utc (DATETIME), actual_departure_utc (DATETIME, nullable), actual_arrival_utc (DATETIME, nullable), status (ENUM: SCHEDULED/DELAYED/CANCELLED/DIVERTED/LANDED/UNKNOWN), delay_minutes (INT, nullable), terminal (TEXT), gate (TEXT), notes (TEXT), is_locked (BOOL, default FALSE), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Relationships: →FlightPassenger(1:N), →Trip.related_flight_id(1:N)
- Event ownership: direct

### 5. FlightPassenger
Junction: Person on a Flight.
- Fields: id (UUID, PK), flight_id (UUID, FK→Flight), person_id (UUID, FK→Person), seat_number (TEXT, nullable), booking_reference (TEXT, nullable), notes (TEXT), status (ENUM: CONFIRMED/TENTATIVE/CANCELLED), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Event ownership: indirect through Flight→Event
- Unique constraint: (flight_id, person_id) — same person cannot be on same flight twice

### 6. Vehicle
A transport vehicle.
- Fields: id (UUID, PK), event_id (UUID, FK→Event), name (TEXT, required), vehicle_type (ENUM: CAR/VAN/MINIBUS/BUS/CUSTOM), capacity (INT, required, >0), license_plate (TEXT), color (TEXT), notes (TEXT), status (ENUM: AVAILABLE/IN_USE/MAINTENANCE/UNAVAILABLE), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Relationships: →Trip.vehicle_id(1:N)
- Event ownership: direct

### 7. Trip
One transport movement.
- Fields: id (UUID, PK), event_id (UUID, FK→Event), direction (ENUM: INBOUND/OUTBOUND/LOCAL), origin (TEXT), destination (TEXT), scheduled_departure_utc (DATETIME), scheduled_arrival_utc (DATETIME, nullable), actual_departure_utc (DATETIME, nullable), actual_arrival_utc (DATETIME, nullable), driver_id (UUID, FK→Driver, nullable), vehicle_id (UUID, FK→Vehicle, nullable), related_flight_id (UUID, FK→Flight, nullable), status (ENUM: PLANNED/CONFIRMED/IN_PROGRESS/COMPLETED/CANCELLED), notes (TEXT), is_locked (BOOL), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Relationships: →TripPassenger(1:N)
- Event ownership: direct
- Constraint: if vehicle_id set, count(active TripPassengers) <= Vehicle.capacity generates alert (not hard block)

### 8. TripPassenger
Junction: Person on a Trip.
- Fields: id (UUID, PK), trip_id (UUID, FK→Trip), person_id (UUID, FK→Person), pickup_location (TEXT), pickup_notes (TEXT), passenger_status (ENUM: ASSIGNED/CONFIRMED/PICKED_UP/DROPPED_OFF/NO_SHOW/CANCELLED), notes (TEXT), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Event ownership: indirect through Trip→Event

### 9. Apartment
An accommodation unit.
- Fields: id (UUID, PK), event_id (UUID, FK→Event), name (TEXT, required), address (TEXT), hebrew_address (TEXT), floor (TEXT), entry_code (TEXT), landlord_name (TEXT), landlord_phone (TEXT), notes (TEXT), status (ENUM: ACTIVE/UNAVAILABLE/CLOSED), total_cost (DECIMAL, nullable), cost_currency (TEXT, nullable), cost_notes (TEXT), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Relationships: →Room(1:N), →ApartmentIssue(1:N)
- Event ownership: direct

### 10. Room
A room within an apartment.
- Fields: id (UUID, PK), apartment_id (UUID, FK→Apartment), name (TEXT, required), floor (TEXT), description (TEXT), notes (TEXT), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Relationships: →SleepingPlace(1:N)
- Event ownership: indirect through Apartment→Event

### 11. SleepingPlace
A specific sleeping position within a room.
- Fields: id (UUID, PK), room_id (UUID, FK→Room), label (TEXT, required), type (ENUM: REGULAR_BED/BUNK_BED/SOFA_BED/MATTRESS/CUSTOM), custom_type_name (TEXT, nullable), position_notes (TEXT), is_active (BOOL, default TRUE), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Relationships: →AccommodationAssignment(1:N)
- Event ownership: indirect through Room→Apartment→Event
- DO NOT add occupant_id here

### 12. AccommodationAssignment
The authoritative occupancy relationship.
- Fields: id (UUID, PK), sleeping_place_id (UUID, FK→SleepingPlace), person_id (UUID, FK→Person), start_date (DATE, inclusive), end_date (DATE, exclusive), status (ENUM: ACTIVE/TEMPORARY/CANCELLED), notes (TEXT), is_locked (BOOL), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Event ownership: indirect through SleepingPlace→Room→Apartment→Event
- Constraint: no overlapping [start_date, end_date) for same sleeping_place_id where status != CANCELLED and is_deleted = FALSE
- Date semantics: start_date inclusive, end_date exclusive. Person sleeps nights start_date through end_date-1.

### 13. Task
An operational task.
- Fields: id (UUID, PK), event_id (UUID, FK→Event), title (TEXT, required), description (TEXT), assignee_id (UUID, FK→Person, nullable), priority (ENUM: CRITICAL/HIGH/MEDIUM/LOW), due_date_utc (DATETIME, nullable), status (ENUM: NEW/IN_PROGRESS/WAITING/COMPLETED/CANCELLED), completed_at_utc, cancelled_at_utc, notes (TEXT), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Event ownership: direct

### 14. ApartmentIssue
An issue reported for an apartment.
- Fields: id (UUID, PK), event_id (UUID, FK→Event), apartment_id (UUID, FK→Apartment), title (TEXT, required), description (TEXT), reporter_id (UUID, FK→Person, nullable), priority (ENUM: CRITICAL/HIGH/MEDIUM/LOW), status (ENUM: OPEN/IN_PROGRESS/RESOLVED/CLOSED), resolved_at_utc, resolution_notes (TEXT), notes (TEXT), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Event ownership: direct (also linked through apartment)

### 15. Expense
A financial expense record.
- Fields: id (UUID, PK), event_id (UUID, FK→Event), description (TEXT, required), category (TEXT), original_amount (DECIMAL, required, source), original_currency (TEXT, ISO 4217, required, source), base_amount (DECIMAL, derived), base_currency (TEXT, derived from Event), exchange_rate (DECIMAL, source once set), exchange_rate_source (ENUM: MANUAL/IMPORTED, source), exchange_rate_timestamp_utc (DATETIME), payer_id (UUID, FK→Person, nullable), expense_date (DATE), receipt_reference (TEXT), notes (TEXT), is_locked (BOOL), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Event ownership: direct

### 16. Payment
A payment from a participant.
- Fields: id (UUID, PK), event_id (UUID, FK→Event), person_id (UUID, FK→Person, required), amount (DECIMAL, required, source), currency (TEXT, ISO 4217, required, source), base_amount (DECIMAL, derived), base_currency (TEXT, derived from Event), exchange_rate (DECIMAL, source once set), exchange_rate_source (ENUM: MANUAL/IMPORTED), exchange_rate_timestamp_utc (DATETIME), payment_date (DATE), payment_method (ENUM: CASH/BANK_TRANSFER/CREDIT_CARD/CHECK/OTHER), reference (TEXT), notes (TEXT), is_locked (BOOL), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Event ownership: direct

### 17. OperationalRule (event-scoped configuration)
Defines the enabled/configured behavior of one canonical rule for one event. The code catalog is an application constant; this record is the event-scoped configuration, not a second code registry.
- Fields: id (UUIDv4, PK), event_id (UUID, FK→Event, required), rule_code (TEXT, required, canonical catalog member), domain (TEXT), severity_default (ENUM), title_template (TEXT), description_template (TEXT), is_active (BOOL, default TRUE), is_dismissable (BOOL), re_trigger_after_dismiss (BOOL, default FALSE), created_at_utc, updated_at_utc, is_deleted, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Event ownership: direct. Unique constraint: `(event_id, rule_code)`.
- Validation: `rule_code` must exactly match the canonical catalog in Section 18. Phase 1 seeds a row per catalog rule for a new event; reserved `UNPAID_BALANCE` is seeded inactive.

### 18. UnresolvedItem
Derived alert record.
- Fields: id (SHA-256 TEXT, PK), event_id (UUID, FK→Event), rule_code (TEXT), entity_type (TEXT), entity_id (UUID), scope_key (TEXT, nullable), severity (ENUM: CRITICAL/HIGH/MEDIUM/LOW/INFO), title (TEXT), description (TEXT), status (ENUM: DETECTED/ACKNOWLEDGED/RESOLVED/DISMISSED), detected_at_utc (DATETIME), acknowledged_at_utc (DATETIME, nullable), resolved_at_utc (DATETIME, nullable), dismissed_at_utc (DATETIME, nullable), dismissed_reason (TEXT, nullable), auto_resolved (BOOL, default FALSE), resolution_notes (TEXT, nullable), created_at_utc (DATETIME), updated_at_utc (DATETIME), deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Event ownership: direct

### 19. AuditEntry
Historical record of operations.
- Fields: id (UUID, PK), event_id (UUID, FK→Event, nullable for global ops), entity_type (TEXT), entity_id (UUID), action (ENUM: CREATE/UPDATE/DELETE/RESTORE/ASSIGN/UNASSIGN/STATUS_CHANGE/LOCK/UNLOCK), timestamp_utc (DATETIME), changes_json (TEXT, nullable), actor_description (TEXT, default 'Manager'), created_at_utc, updated_at_utc, deleted_at_utc (DATETIME, nullable), version (INT, default 1), last_modified_by_device_id (TEXT, nullable)
- Event ownership: direct where applicable
- Append-only: never modified, never deleted
- MVP: structural only, critical operations logged


Relationship diagram (describe in words — mermaid optional):
- Event 1:N → Person, Driver, Vehicle, Flight, Trip, Apartment, Task, ApartmentIssue, Expense, Payment, UnresolvedItem
- Person 1:N → FlightPassenger, TripPassenger, AccommodationAssignment, Task(assignee), ApartmentIssue(reporter), Expense(payer), Payment
- Flight 1:N → FlightPassenger
- Flight 1:N → Trip(related_flight)
- Trip 1:N → TripPassenger
- Trip N:1 → Driver, Vehicle
- Apartment 1:N → Room, ApartmentIssue
- Room 1:N → SleepingPlace
- SleepingPlace 1:N → AccommodationAssignment
- AccommodationAssignment N:1 → Person, SleepingPlace
