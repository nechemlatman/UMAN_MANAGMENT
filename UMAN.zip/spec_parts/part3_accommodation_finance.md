## SECTION 14: Accommodation & Sleeping Logistics

### 14.1 Hierarchy and Data Models
The accommodation model is strictly hierarchical: **Apartment → Room → SleepingPlace → AccommodationAssignment**.

#### Apartment
* **id**: UUIDv4
* **event_id**: Foreign Key
* **name**: String
* **address**: String
* **hebrew_address**: String
* **floor**: String/Integer
* **entry_code**: String
* **landlord_name**: String
* **landlord_phone**: String
* **notes**: Text
* **status**: Enum (`ACTIVE`, `UNAVAILABLE`, `CLOSED`)
* **total_cost**: Decimal
* **cost_currency**: ISO 4217
* **cost_notes**: Text
* **created_at_utc**, **updated_at_utc**: Timestamp
* **is_deleted**: Boolean

#### Room
* **id**: UUIDv4
* **apartment_id**: Foreign Key
* **name/number**: String
* **floor**: String/Integer
* **description**: Text
* **notes**: Text
* **created_at_utc**, **updated_at_utc**: Timestamp
* **is_deleted**: Boolean

#### SleepingPlace
* **id**: UUIDv4
* **room_id**: Foreign Key
* **label**: String
* **type**: Enum (`REGULAR_BED`, `BUNK_BED`, `SOFA_BED`, `MATTRESS`, `CUSTOM`)
* **custom_type_name**: String (Nullable, required if type is `CUSTOM`)
* **position_notes**: Text
* **is_active**: Boolean
* **created_at_utc**, **updated_at_utc**: Timestamp
* **is_deleted**: Boolean

#### AccommodationAssignment
The system explicitly avoids a simple "Occupant" field on the sleeping place. Instead, it utilizes an event-scoped assignment model to track historical and future occupancy securely.

* **id**: UUIDv4
* **sleeping_place_id**: Foreign Key
* **person_id**: Foreign Key
* **start_date**: Date (Inclusive)
* **end_date**: Date (Exclusive)
* **status**: Enum (`ACTIVE`, `TEMPORARY`, `CANCELLED`)
* **notes**: Text
* **is_locked**: Boolean
* **created_at_utc**, **updated_at_utc**: Timestamp
* **is_deleted**: Boolean

### 14.2 Business Rules and Logic

#### Date Semantics
* `start_date` is **inclusive** (representing the first night the person is sleeping in the place).
* `end_date` is **exclusive** (representing the checkout day; the person does not sleep there on this night).
* *Example*: A person assigned from `2025-10-01` to `2025-10-05` sleeps there on the nights of Oct 1, 2, 3, and 4, checking out on Oct 5.

#### Same-Day Turnover
* A person checking out and another checking in on the same day do **not** conflict.
* *Example*: Person A with `end_date=Oct 3` and Person B with `start_date=Oct 3` have no overlap. Person A leaves on Oct 3, and Person B arrives on Oct 3.

#### Overlap Detection
* Two assignments for the same `sleeping_place` are considered overlapping if their `[start_date, end_date)` intervals mathematically intersect.
* When an overlap is detected, the system generates an `ACCOMMODATION_OVERLAP` alert. The manager must resolve this manually.

#### Person Without Sleeping Place
* The system evaluates each night within the event's active accommodation period. If a person has no active `AccommodationAssignment` for a given night, a `PERSON_WITHOUT_SLEEPING_PLACE` alert is generated.

#### Capacity Override
* Managers possess the authority to explicitly override standard capacity rules (e.g., placing an extra mattress in a room).
* This is achieved by utilizing the `is_locked` flag on the assignment, accompanied by mandatory `notes` explaining the override context.

#### Reassignment
* To move a person, the system mandates creating a new `AccommodationAssignment` and optionally cancelling or ending the previous one.
* The system must never silently update or mutate assignments to move people.

#### Temporary Assignment
* Assignments marked with `status=TEMPORARY` are surfaced distinctly in the user interface (e.g., visually differentiated).
* Temporary assignments are still completely subject to standard overlap rules and capacity constraints.


## SECTION 15: Tasks & Apartment Issues

### 15.1 Task Management

#### Task Model
* **id**: UUIDv4
* **event_id**: Foreign Key
* **title**: String
* **description**: Text
* **assignee_id**: Foreign Key to Person (Nullable)
* **priority**: Enum (`CRITICAL`, `HIGH`, `MEDIUM`, `LOW`)
* **due_date_utc**: Timestamp (Nullable)
* **due_date_local**: Timestamp (Nullable, utilized for display purposes)
* **status**: Enum (`NEW`, `IN_PROGRESS`, `WAITING`, `COMPLETED`, `CANCELLED`)
* **completed_at_utc**: Timestamp (Nullable)
* **cancelled_at_utc**: Timestamp (Nullable)
* **notes**: Text
* **created_at_utc**, **updated_at_utc**: Timestamp
* **is_deleted**: Boolean

#### Task Lifecycle
* Standard progression: `NEW` → `IN_PROGRESS` → `COMPLETED`
* Delayed progression: `NEW` → `IN_PROGRESS` → `WAITING` → `IN_PROGRESS` → `COMPLETED`
* Cancellation: Any non-terminal state can transition to `CANCELLED`.
* Terminal states (`COMPLETED`, `CANCELLED`) can be explicitly restored to active states by a manager.

#### Overdue Detection
* If a task's `due_date_utc` is in the past (`< now`) AND its `status` is NOT IN (`COMPLETED`, `CANCELLED`), the system generates an `OVERDUE_TASK` alert.

### 15.2 Apartment Issues

#### ApartmentIssue Model
* **id**: UUIDv4
* **apartment_id**: Foreign Key
* **event_id**: Foreign Key
* **title**: String
* **description**: Text
* **reporter_id**: Foreign Key to Person (Nullable)
* **priority**: Enum (`CRITICAL`, `HIGH`, `MEDIUM`, `LOW`)
* **status**: Enum (`OPEN`, `IN_PROGRESS`, `RESOLVED`, `CLOSED`)
* **resolved_at_utc**: Timestamp (Nullable)
* **resolution_notes**: Text
* **photos_json**: JSON (Nullable, containing local file references)
* **notes**: Text
* **created_at_utc**, **updated_at_utc**: Timestamp
* **is_deleted**: Boolean

#### Issue Alerting
* Any issue where the `status` is NOT IN (`RESOLVED`, `CLOSED`) immediately generates an `UNRESOLVED_APARTMENT_ISSUE` alert.


## SECTION 16: Financial & Multi-Currency System

### 16.1 Core Design Principles
* **Preservation of Origin**: Original transaction currencies and amounts are ALWAYS preserved unconditionally.
* **Derived Conversions**: Converted or base amounts are strictly derived data; they never overwrite origin values.
* **Reproducibility**: Exchange rates utilized for conversions are preserved to guarantee historical reproducibility.
* **Transparency**: No undocumented or implicit conversions occur.
* **Locking**: Managers can lock finalized financial calculations to prevent future rate fluctuations from altering historical records.

### 16.2 Financial Models

#### Expense Model
* **id**: UUIDv4
* **event_id**: Foreign Key
* **description**: String
* **category**: String
* **original_amount**: Decimal
* **original_currency**: ISO 4217
* **base_amount**: Decimal (Derived)
* **base_currency**: ISO 4217 (Inherited from Event)
* **exchange_rate**: Decimal
* **exchange_rate_source**: Enum (`MANUAL`, `IMPORTED`)
* **exchange_rate_timestamp_utc**: Timestamp
* **payer_id**: Foreign Key to Person (Nullable)
* **expense_date**: Date
* **receipt_reference**: String
* **notes**: Text
* **is_locked**: Boolean
* **created_at_utc**, **updated_at_utc**: Timestamp
* **is_deleted**: Boolean

#### Payment Model
* **id**: UUIDv4
* **event_id**: Foreign Key
* **person_id**: Foreign Key
* **amount**: Decimal
* **currency**: ISO 4217
* **base_amount**: Decimal (Derived)
* **base_currency**: ISO 4217
* **exchange_rate**: Decimal
* **exchange_rate_source**: Enum (`MANUAL`, `IMPORTED`)
* **exchange_rate_timestamp_utc**: Timestamp
* **payment_date**: Date
* **payment_method**: Enum (`CASH`, `BANK_TRANSFER`, `CREDIT_CARD`, `CHECK`, `OTHER`, `CUSTOM`)
* **reference**: String
* **notes**: Text
* **is_locked**: Boolean
* **created_at_utc**, **updated_at_utc**: Timestamp
* **is_deleted**: Boolean

### 16.3 Logic and Rules

#### Financial totals and deferred allocation
* All monetary amounts with a recorded rate are converted to the event's `base_currency` using that precise recorded `exchange_rate`.
* Expense allocation, participant share, and therefore a final per-person unpaid balance are **not defined for MVP implementation**. There is no authoritative formula and no allocation entity in this baseline.
* The `UNPAID_BALANCE` code remains a reserved, inactive rule definition. Phase 1 must not evaluate it or display a calculated unpaid balance until the Product Owner approves the allocation model and acceptance tests.
* Phase 1 may persist and list `Expense` and `Payment`, validate/reproduce their individual base conversions, and show non-allocated event-level totals only. It must not infer allocation from payments, names, groups, or equal shares.

#### Currency Rules
* **No Invention**: The system explicitly never invents or guesses exchange rates.
* **Manual Rates**: Managers can manually input an exchange rate, marking the source as `MANUAL`.
* **Imported Rates**: (Future Capability) The system will support importing rates, marking the source as `IMPORTED`.
* **Preservation**: The specific rate utilized for a finalized calculation is preserved via the `is_locked` mechanism.
* **Reproducibility Guarantee**: Historical calculations must remain reproducible. Identical inputs processed with identical stored rates must yield the exact same result.
* **Immutability**: Original monetary information is never replaced or obfuscated by converted information.
