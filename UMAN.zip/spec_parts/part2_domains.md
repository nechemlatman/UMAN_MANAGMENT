## SECTION 6: MVP Scope vs. Phase 2 Boundary

The system follows a strict isolation between the initial offline-first MVP and subsequent cloud-enabled phases. The MVP boundary is designed to deliver a complete, standalone operational tool without the complexities of distributed state.

### Feature Classification

| Feature Area | Included in MVP (Build Now) | Strictly Deferred (Phase 2+) |
| :--- | :--- | :--- |
| **Core Architecture** | Offline-first operation, encrypted local storage, secure backup/restore, audit readiness (structural) | Cloud backend, remote database, CRDT, Event Sourcing, distributed state |
| **Event & Lifecycle** | Event management, lifecycle stages, multi-event isolation | Multi-user synchronization, sync UI, conflict-resolution UI |
| **Identity & Access** | Single manager control (device owner) | Remote authentication, RBAC UI, field-level permissions, invitations |
| **People & Logistics**| People management, Flight management & manifests, Driver & Vehicle management, Multi-passenger transport | Global person identity across events |
| **Accommodation** | Apartment → Room → SleepingPlace → Assignment, Date-aware sleeping assignments | Automated hotel PMS integrations |
| **Operations** | Tasks & Apartment Issues, Reactive domain rules, Control Center, Today view, Unresolved items, Universal search | Meals, Menus, Recipes, Cook calculations, Food inventory, automated purchasing |
| **Financials** | Expenses, Participant Payments, Multi-currency calculations | Banking integrations, automated currency rate sync |
| **Localization** | Hebrew/English bilingual UX with RTL/LTR | Additional languages beyond HE/EN |
| **Customization** | Manager customization, event-scoped settings, local data import/export | Global organization-level templates |

### Shared/Read-Only Output (MVP)

Data sharing in the MVP is entirely one-way and read-only. There is no remote state, no editable shared state, and no user accounts for participants or staff.

*   **Snapshots:** Generation of read-only snapshots tailored for WhatsApp sharing.
*   **Supported Snapshot Types:** Transport lists, accommodation lists, arrival/departure manifests, task lists, and operational summaries.
*   **Presentation:** Snapshots must be clearly identifiable as static point-in-time documents, distinct from live operational state.

---

## SECTION 7: Event Model & Lifecycle

The **Event** is the root operational container. Every data record in the system belongs to exactly one event. There is strict cross-event isolation; data does not leak between events.

**Data Model: Event**
*   `id` (UUIDv4)
*   `name` (String)
*   `hebrew_name` (String, nullable)
*   `description` (Text, nullable)
*   `year` (Integer)
*   `start_date` (Date)
*   `end_date` (Date)
*   `base_currency` (String, ISO 4217)
*   `lifecycle_stage` (Enum: PLANNING, READY, TRAVEL, IN_UMAN, DEPARTURE, CLOSEOUT, ARCHIVED)
*   `manager_notes` (Text, nullable)
*   `settings` (JSON)
*   `created_at_utc` (Timestamp)
*   `updated_at_utc` (Timestamp)
*   `is_deleted` (Boolean)

### Lifecycle Stages & Definitions

1.  **PLANNING:** Initial setup. All data entry permitted. No operational restrictions or active alerts triggered by timeline proximity.
2.  **READY:** Pre-travel preparation is complete. The manager confirms readiness. All structural data (apartments, vehicles) should be finalized and reviewed.
3.  **TRAVEL:** Active travel period. Inbound flights and transport are active. Operational alerts (e.g., flight delays, missing pickups) are critical.
4.  **IN_UMAN:** On-site operations phase. Accommodation assignments are active. Tasks and apartment issues take operational priority.
5.  **DEPARTURE:** Return travel period. Outbound flights and return transport are active.
6.  **CLOSEOUT:** Financial and operational reconciliation. No new operational assignments can be created. Manager reviews and finalizes all records.
7.  **ARCHIVED:** Read-only historical record. No editing permitted except authorized corrections by the manager.

### Lifecycle Transitions

| From | To | Valid | Requires Manager Authorization | Notes / Behavior |
| :--- | :--- | :--- | :--- | :--- |
| PLANNING | READY | Yes | Yes | Validates that minimum setup requirements are met. |
| READY | PLANNING | Yes | Yes | Reversible if more core planning is required. |
| READY | TRAVEL | Yes | No | Can be triggered manually or by timeline. |
| TRAVEL | IN_UMAN | Yes | No | Triggered when majority of participants have arrived. |
| IN_UMAN | DEPARTURE | Yes | No | Triggered when departures begin. |
| DEPARTURE | CLOSEOUT | Yes | Yes | Stops all active operational monitoring. |
| CLOSEOUT | ARCHIVED | Yes | Yes | Locks event. Read-only enforced at application layer. |
| ANY | ARCHIVED | Yes | Yes | Force archive (e.g., event cancelled). |
| ARCHIVED | CLOSEOUT | No | N/A | Archiving is a final state for operational purposes. |

*   **Historical Visibility:** Archived events are visible in search and reference lists but exclude active operational widgets (Today View, Unresolved Items).
*   **Event Isolation Rules:** A Person, Trip, or Flight created in Event A cannot be referenced or linked to from Event B.

---

## SECTION 8: Manager Control & Customization

The system provides targeted, event-scoped customization capabilities to adapt to specific group needs.

**Supported Customizations:**
*   Custom categories for expenses
*   Custom sleeping place types beyond built-in defaults
*   Custom payment methods
*   Custom task priorities and labels
*   Custom status labels where appropriate
*   Event-level settings (base currency, default airport, timezone preferences)
*   Display preferences (RTL/LTR overrides, default views)

**Constraints:**
All customization is strictly event-scoped. Changes apply only to the current Event. Customizations cannot alter core domain rules, lifecycle transitions, or required entity fields.

---

## SECTION 9: People Management

**MVP Model:** The `Person` entity is event-scoped. Each event maintains its own isolated person records. Cross-event person reuse is deferred to a future capability.
*Justification:* Event-scoped persons drastically simplify data structure, eliminate cross-event data leakage risks, and negate the need for a global identity management system during offline MVP operations.

**Data Model: Person**
*   `id` (UUIDv4)
*   `event_id` (UUID, FK)
*   `first_name` (String)
*   `last_name` (String)
*   `hebrew_first_name` (String, nullable)
*   `hebrew_last_name` (String, nullable)
*   `phone` (String)
*   `whatsapp_phone` (String, nullable)
*   `email` (String, nullable)
*   `passport_name` (String, nullable)
*   `passport_number` (String, nullable)
*   `passport_expiration_date` (Date, nullable)
*   `date_of_birth` (Date, nullable)
*   `nationality` (String, nullable)
*   `emergency_contact_name` (String, nullable)
*   `emergency_contact_phone` (String, nullable)
*   `notes` (Text, nullable)
*   `custom_fields` (JSON)
*   `status` (Enum: ACTIVE, INACTIVE)
*   `created_at_utc` (Timestamp)
*   `updated_at_utc` (Timestamp)
*   `is_deleted` (Boolean)

**Relationships:**
*   → `FlightPassenger` (1:N)
*   → `TripPassenger` (1:N)
*   → `AccommodationAssignment` (1:N)
*   → `Task` (Assignee) (1:N)
*   → `ApartmentIssue` (Reporter) (1:N)
*   → `Expense` (Payer) (1:N)
*   → `Payment` (1:N)

**Behaviors:**
*   **Search:** Supports Hebrew, English, and mixed-language querying.
*   **Deletion:** Soft delete only. Preserves relationships for historical accuracy, marks record as `is_deleted = true`. Supports restore.
*   **WhatsApp Integration:** Read-only snapshot sharing directly to WhatsApp via intent/URL schema.
*   **Duplicate Detection:** System evaluates name similarity and phone number matches during creation/import. If a potential duplicate is detected, the system issues a warning. The manager makes the final decision. The system **never** auto-merges person records.

---

## SECTION 10: Flight Management

The system treats Flight information as source data input by the manager. The system is NOT an authoritative flight tracker; it strictly tracks the manager's known state of operations.

**Data Model: Flight**
*   `id` (UUIDv4)
*   `event_id` (UUID, FK)
*   `direction` (Enum: INBOUND, OUTBOUND)
*   `airline` (String)
*   `flight_number` (String)
*   `departure_airport` (String)
*   `arrival_airport` (String)
*   `scheduled_departure_utc` (Timestamp)
*   `scheduled_arrival_utc` (Timestamp)
*   `actual_departure_utc` (Timestamp, nullable)
*   `actual_arrival_utc` (Timestamp, nullable)
*   `status` (Enum: SCHEDULED, DELAYED, CANCELLED, DIVERTED, LANDED, UNKNOWN)
*   `delay_minutes` (Integer, nullable)
*   `terminal` (String, nullable)
*   `gate` (String, nullable)
*   `notes` (Text, nullable)
*   `is_locked` (Boolean)
*   `created_at_utc` (Timestamp)
*   `updated_at_utc` (Timestamp)
*   `is_deleted` (Boolean)

**Data Model: FlightPassenger**
*   `id` (UUIDv4)
*   `flight_id` (UUID, FK)
*   `person_id` (UUID, FK)
*   `seat_number` (String, nullable)
*   `booking_reference` (String, nullable)
*   `notes` (Text, nullable)
*   `status` (Enum: CONFIRMED, TENTATIVE, CANCELLED)
*   `created_at_utc` (Timestamp)
*   `updated_at_utc` (Timestamp)
*   `is_deleted` (Boolean)

**Flight Status Change Behaviors:**
*   **DELAYED:** Generates an advisory for the Control Center. Does **NOT** automatically change associated transport schedules.
*   **CANCELLED:** Generates a critical alert. Transport and accommodation are flagged as potentially affected. The manager must manually review and reallocate.
*   **Schedule Change:** Generates an alert. Original schedule data is preserved for comparison, and the new schedule is recorded. The manager reviews transport impact.

---

## SECTION 11: Driver Management

A `Driver` is treated as a separate, distinct domain entity and is **NOT** embedded within a Vehicle record.

**Data Model: Driver**
*   `id` (UUIDv4)
*   `event_id` (UUID, FK)
*   `name` (String)
*   `phone` (String)
*   `whatsapp_phone` (String, nullable)
*   `license_info` (String, nullable)
*   `notes` (Text, nullable)
*   `status` (Enum: AVAILABLE, BUSY, UNAVAILABLE, OFF_DUTY)
*   `created_at_utc` (Timestamp)
*   `updated_at_utc` (Timestamp)
*   `is_deleted` (Boolean)

**Relationships & Behaviors:**
*   → `Trip` (driver for trip) (1:N over time)
*   A Driver is NOT permanently bound to a Vehicle. A driver may operate different vehicles at different times, and may be assigned to different trips flexibly.

---

## SECTION 12: Vehicle Management

**Data Model: Vehicle**
*   `id` (UUIDv4)
*   `event_id` (UUID, FK)
*   `name_or_identifier` (String)
*   `vehicle_type` (Enum: CAR, VAN, MINIBUS, BUS, CUSTOM)
*   `capacity` (Integer - maximum passengers)
*   `license_plate` (String, nullable)
*   `color` (String, nullable)
*   `notes` (Text, nullable)
*   `status` (Enum: AVAILABLE, IN_USE, MAINTENANCE, UNAVAILABLE)
*   `created_at_utc` (Timestamp)
*   `updated_at_utc` (Timestamp)
*   `is_deleted` (Boolean)

**Relationships & Behaviors:**
*   → `Trip` (vehicle for trip) (1:N over time)
*   A Vehicle is NOT permanently bound to a Driver.
*   `capacity` is strictly used by the Domain Rules engine to validate against active trip passenger assignments.

---

## SECTION 13: Transport Management

Transport Management centers around the `Trip`, coordinating people, drivers, and vehicles.

**Data Model: Trip**
*   `id` (UUIDv4)
*   `event_id` (UUID, FK)
*   `direction` (Enum: INBOUND, OUTBOUND, LOCAL)
*   `origin` (String)
*   `destination` (String)
*   `scheduled_departure_utc` (Timestamp)
*   `scheduled_arrival_utc` (Timestamp)
*   `actual_departure_utc` (Timestamp, nullable)
*   `actual_arrival_utc` (Timestamp, nullable)
*   `driver_id` (UUID, FK, nullable)
*   `vehicle_id` (UUID, FK, nullable)
*   `related_flight_id` (UUID, FK, nullable)
*   `status` (Enum: PLANNED, CONFIRMED, IN_PROGRESS, COMPLETED, CANCELLED)
*   `notes` (Text, nullable)
*   `is_locked` (Boolean)
*   `created_at_utc` (Timestamp)
*   `updated_at_utc` (Timestamp)
*   `is_deleted` (Boolean)

**Data Model: TripPassenger**
*   `id` (UUIDv4)
*   `trip_id` (UUID, FK)
*   `person_id` (UUID, FK)
*   `pickup_location` (String, nullable)
*   `pickup_notes` (Text, nullable)
*   `passenger_status` (Enum: ASSIGNED, CONFIRMED, PICKED_UP, DROPPED_OFF, NO_SHOW, CANCELLED)
*   `notes` (Text, nullable)
*   `created_at_utc` (Timestamp)
*   `updated_at_utc` (Timestamp)
*   `is_deleted` (Boolean)

**Domain Rules & Behaviors:**
*   **Capacity Validation:** A trip is over capacity only when its count of active passengers is strictly greater than the related vehicle's capacity (`passenger_count > capacity`). Exactly at capacity is valid. The system will **never** silently remove passengers to resolve an overallocation; the manager must resolve it.
*   **Driver/Vehicle Replacement:** Reassigning a driver or vehicle preserves historical context. The previous assignment is recorded in the structural audit log. The new assignment becomes the live source data.
*   **Flight-Transport Linkage:** A trip MAY reference a related flight (e.g., Airport Transfer). If the related flight changes (e.g., delayed or cancelled), the system generates advisories but **NEVER** automatically modifies the trip schedule or assignments. The manager must review the alert and confirm operational changes manually.
