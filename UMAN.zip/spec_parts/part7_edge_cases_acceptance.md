## SECTION 35: Uman Operational Edge Cases & Mitigation Rules

For EACH edge case, provide:
1. Source data affected
2. Derived consequence
3. Operational alert generated
4. Automatic behavior allowed
5. Manager confirmation required?
6. Result if manager takes no action
7. Data preservation requirement

Edge cases:

### Flight Delay
1. Source: Flight.actual_departure_utc later than scheduled, Flight.delay_minutes updated
2. Derived: Related trips may need time adjustment. FLIGHT_DELAY_IMPACT alert.
3. Alert: FLIGHT_DELAY_IMPACT — severity based on delay magnitude and transport dependency
4. Auto: Update flight status to DELAYED. Generate alert. NO auto-change to trips.
5. Manager: Yes — must review affected trips and decide whether to reschedule
6. No action: Alert remains active. Trips unchanged. Passengers may miss transport.
7. Preserve: Original schedule, actual times, all trip data unchanged

### Flight Cancellation
1. Source: Flight.status = CANCELLED
2. Derived: All passengers need alternative. All related trips affected.
3. Alert: FLIGHT_CANCELLED — CRITICAL severity
4. Auto: Update flight status. Generate alert. NO auto-change to passengers or trips.
5. Manager: Yes — must reassign passengers to alternative flights and review transport
6. No action: Alert remains critical. Passengers and trips unchanged.
7. Preserve: Original flight record, all passenger assignments (status updated)

### Flight Schedule Change
1. Source: Flight scheduled times updated by manager
2. Derived: Related trips may be misaligned
3. Alert: FLIGHT_DELAY_IMPACT if related trips exist
4. Auto: Generate alert only. NO auto-modify trips.
5. Manager: Yes
6. No action: Alert persists. Trips may be misaligned with actual flight times.
7. Preserve: Both old and new schedule (via audit), trip data unchanged

### Actual Arrival Differing from Schedule
1. Source: Flight.actual_arrival_utc differs from scheduled
2. Derived: Informational update. Transport may be affected.
3. Alert: FLIGHT_DELAY_IMPACT if significant; the threshold is event configuration, default 30 minutes
4. Auto: Record actual time. Generate alert if threshold exceeded.
5. Manager: Only if transport is affected
6. No action: Informational alert. Historical record preserved.
7. Preserve: Both scheduled and actual times

### Border Delay
1. Source: Not directly modeled. Manager updates Trip or Person notes.
2. Derived: Trip may be delayed.
3. Alert: None auto-generated. Manager can create manual task.
4. Auto: None
5. Manager: Discretionary
6. No action: No system impact
7. Preserve: Manager notes

### Driver Replacement
1. Source: Trip.driver_id changed
2. Derived: Previous driver freed. New driver assigned.
3. Alert: None (normal operation). Audit trail records change.
4. Auto: Update trip driver. No other changes.
5. Manager: Implicit (manager initiates the change)
6. N/A
7. Preserve: Audit entry of previous driver assignment

### Vehicle Replacement
1. Source: Trip.vehicle_id changed
2. Derived: Capacity may change. If new vehicle smaller, overcapacity possible.
3. Alert: VEHICLE_OVER_CAPACITY if new vehicle capacity < current passengers
4. Auto: Update trip vehicle. Generate capacity alert if needed.
5. Manager: If overcapacity results
6. No action: Overcapacity alert persists
7. Preserve: Audit entry of previous vehicle

### Vehicle Breakdown
1. Source: Vehicle.status = MAINTENANCE/UNAVAILABLE
2. Derived: Active trips using this vehicle affected
3. Alert: TRIP_VEHICLE_UNAVAILABLE for each affected trip
4. Auto: Generate alerts. NO auto-reassign vehicle.
5. Manager: Yes — must assign replacement vehicle
6. No action: Alerts persist. Trips show unavailable vehicle.
7. Preserve: Vehicle record, trip records unchanged

### Vehicle Overcapacity
1. Source: TripPassenger count > Vehicle.capacity for a trip
2. Derived: VEHICLE_OVER_CAPACITY
3. Alert: VEHICLE_OVER_CAPACITY — HIGH severity
4. Auto: Generate alert only. NEVER silently remove passengers.
5. Manager: Yes — must either remove passengers or assign larger vehicle
6. No action: Alert persists. All passengers remain assigned.
7. Preserve: All passenger assignments

### Passenger Added Last Minute
1. Source: New TripPassenger created
2. Derived: Capacity recheck triggered
3. Alert: VEHICLE_OVER_CAPACITY if capacity exceeded
4. Auto: Add passenger. Check capacity. Generate alert if needed.
5. Manager: If overcapacity
6. No action: Passenger added, alert persists if overcapacity
7. Preserve: All data

### Passenger Removed from Trip
1. Source: TripPassenger.status = CANCELLED or is_deleted
2. Derived: Capacity freed. Person may need alternative transport.
3. Alert: PERSON_WITHOUT_TRANSPORT if person has no other transport for this movement
4. Auto: Remove from trip. Check if person still has transport.
5. Manager: If person needs alternative transport
6. No action: Person has no transport for this leg. Alert persists.
7. Preserve: TripPassenger record (soft delete or cancelled status)

### Transport Reassignment
1. Source: Person moved from one trip to another
2. Derived: Capacity changes on both trips
3. Alert: Capacity alerts if either trip affected
4. Auto: Update assignments. Recheck capacity.
5. Manager: Initiates the change
6. N/A
7. Preserve: Audit trail of reassignment

### Accommodation Reassignment
1. Source: New AccommodationAssignment created, old one ended/cancelled
2. Derived: Overlap check on new assignment
3. Alert: ACCOMMODATION_OVERLAP if conflict
4. Auto: Create new assignment. Check overlap. NO auto-cancel old.
5. Manager: Must explicitly end old assignment if needed
6. No action: Both assignments may coexist (overlap alert)
7. Preserve: Both assignment records

### Sleeping-Place Conflict
1. Source: Two active assignments for same sleeping_place with overlapping dates
2. Derived: ACCOMMODATION_OVERLAP
3. Alert: ACCOMMODATION_OVERLAP — HIGH severity
4. Auto: Detect and alert only. NEVER silently remove an assignment.
5. Manager: Yes — must resolve (cancel one, adjust dates, or override)
6. No action: Alert persists. Both assignments remain.
7. Preserve: Both assignment records

### Early Departure
1. Source: Manager adjusts Person's outbound flight/transport to earlier date
2. Derived: Accommodation assignment may extend beyond departure
3. Alert: Informational — accommodation extends past departure
4. Auto: Alert only
5. Manager: May adjust accommodation
6. No action: Accommodation remains as-is
7. Preserve: All records

### Extended Stay
1. Source: Person staying longer than originally planned
2. Derived: May need additional accommodation nights
3. Alert: PERSON_WITHOUT_SLEEPING_PLACE for additional nights
4. Auto: Detect uncovered nights. Alert.
5. Manager: Must extend or create new accommodation assignment
6. No action: Alert persists for uncovered nights
7. Preserve: All records

### Same-Day Accommodation Turnover
1. Source: Person A end_date = Oct 3, Person B start_date = Oct 3, same sleeping place
2. Derived: No conflict (end_date exclusive). Valid turnover.
3. Alert: None — this is expected behavior
4. Auto: Allow without alert
5. Manager: No action needed
6. N/A
7. Preserve: Both assignments

### Missing Passenger Information
1. Source: Person record missing critical fields (passport, phone)
2. Derived: PERSON_MISSING_CRITICAL_INFO
3. Alert: MEDIUM severity, informational
4. Auto: Alert only
5. Manager: Should complete information before travel
6. No action: Alert persists. Operations continue.
7. Preserve: Partial record

### Incomplete Flight Information
1. Source: Flight missing departure/arrival times
2. Derived: Cannot calculate transport dependencies
3. Alert: FLIGHT_MISSING_INFO — MEDIUM
4. Auto: Alert only
5. Manager: Should complete flight details
6. No action: Alert persists. Transport linking degraded.
7. Preserve: Partial flight record

### Cash Payment
1. Source: Payment with method=CASH, potentially foreign currency
2. Derived: Balance calculation using recorded exchange rate
3. Alert: None unless balance-related
4. Auto: Record payment. Calculate base amount.
5. Manager: Enters exchange rate if foreign currency
6. N/A
7. Preserve: Original amount, currency, rate

### Multiple Currencies
1. Source: Expenses/payments in various currencies
2. Derived: All converted to base_currency using recorded rates
3. Alert: EXPENSE_WITHOUT_RATE if rate missing
4. Auto: Convert using recorded rate. Alert if rate missing.
5. Manager: Must provide exchange rates
6. No action: Amounts unconverted. Totals incomplete.
7. Preserve: All original amounts and currencies

### Manual Exchange Rate
1. Source: Manager enters exchange_rate, source=MANUAL
2. Derived: base_amount calculated using this rate
3. Alert: None
4. Auto: Calculate conversion
5. Manager: Provides rate
6. N/A
7. Preserve: Rate, source, timestamp

### Accidental Deletion
1. Source: is_deleted = TRUE on a record
2. Derived: Record hidden from active views. Relationships preserved.
3. Alert: None (deliberate action with confirmation)
4. Auto: Soft-delete only. Confirmation required before delete.
5. Manager: Confirmation before delete. Can restore.
6. N/A
7. Preserve: Full record, soft-deleted. Restorable.

### Application Restart During Operation
1. Source: App killed mid-operation
2. Derived: Depends on transaction state
3. Alert: None (system handles)
4. Auto: Database transactions ensure atomicity. Either committed or not.
5. Manager: May need to re-enter uncommitted data
6. N/A
7. Preserve: All committed transactions. Uncommitted discarded safely.

### Device Restart
Same as application restart. Database integrity maintained by SQLite/transaction semantics.

### Backup Interruption
1. Source: Backup file partially written
2. Derived: Invalid backup file
3. Alert: Backup failed notification
4. Auto: Mark backup as failed/incomplete
5. Manager: Should retry backup
6. No action: No valid backup exists for this attempt
7. Preserve: Current database unaffected

### Failed Restore
1. Source: Restore process fails at any step
2. Derived: Current database preserved
3. Alert: Restore failed notification with reason
4. Auto: Roll back to pre-restore state
5. Manager: Can retry or use different backup
6. No action: Current database intact
7. Preserve: Pre-restore backup exists

### Database Corruption
1. Source: SQLite integrity check fails
2. Derived: Data may be unreliable
3. Alert: Critical — database corruption detected
4. Auto: Detect on startup. Warn manager. Offer restore from backup.
5. Manager: Should restore from most recent valid backup
6. No action: Application may be unstable. Repeated warnings.
7. Preserve: Corrupted database file retained as-is for potential recovery. Restore from backup.

### Schema Migration Failure
1. Source: Migration script fails
2. Derived: App cannot operate with mismatched schema
3. Alert: Migration failed notification
4. Auto: Restore from pre-migration backup
5. Manager: Must update app or contact support
6. No action: App restored to pre-migration state
7. Preserve: Pre-migration backup, original database

### Poor/No Connectivity
1. Source: Network unavailable
2. Derived: No impact on MVP (fully offline)
3. Alert: None needed for MVP
4. Auto: Continue normal operation
5. Manager: No action needed
6. N/A
7. Preserve: All data local

### Future Multi-Manager Conflicting Edits
1. Source: [FUTURE] Two managers edit same record simultaneously
2. Derived: [FUTURE] Conflict detected during sync
3. Alert: [FUTURE] Conflict resolution required
4. Auto: [FUTURE] Entity-specific conflict strategy
5. Manager: [FUTURE] Reviews and resolves conflicts
6. No action: [FUTURE] Conflict remains unresolved until addressed
7. Preserve: Both versions until resolved

## SECTION 36: Acceptance Criteria

Complete, testable end-to-end scenarios:

### AC-01: Accommodation Assignment & Overlap Detection
Preconditions: Event exists, Apartment with Room and SleepingPlace created, Person A and Person B exist.
1. Assign Person A to SleepingPlace S1, dates Oct 1-5 → SUCCESS
2. Assign Person B to SleepingPlace S1, dates Oct 3-8 → SUCCESS (assignment created)
3. System detects overlapping dates (Oct 3-5) → ACCOMMODATION_OVERLAP alert generated
4. Verify alert references both assignments, both persons, the sleeping place, and the overlapping dates
5. Manager cancels Person A's assignment effective Oct 3 (updates end_date to Oct 3) → Alert auto-resolves
6. Verify no active ACCOMMODATION_OVERLAP for S1 in this date range
7. Verify Person A now has PERSON_WITHOUT_SLEEPING_PLACE for Oct 3-5

### AC-02: Transport Capacity & Alert Resolution
1. Create Vehicle V1 with capacity=3
2. Create Trip T1 with Vehicle V1
3. Add Person A, B, C as TripPassengers → SUCCESS, no alert
4. Add Person D as TripPassenger → SUCCESS (passenger added)
5. System generates VEHICLE_OVER_CAPACITY for Trip T1 (4 > 3)
6. Verify all 4 passengers remain assigned (no silent removal)
7. Manager removes Person D from Trip T1 → Alert auto-resolves
8. Verify VEHICLE_OVER_CAPACITY cleared

### AC-03: Flight Change Impact on Transport
1. Create Flight F1 arriving 14:00
2. Create Trip T1 linked to F1, departing 15:00
3. Add passengers to both
4. Update F1 arrival to 18:00 (schedule change)
5. System generates FLIGHT_DELAY_IMPACT alert
6. Verify Trip T1 is UNCHANGED (still departing 15:00)
7. Alert clearly indicates the flight-transport misalignment
8. Manager updates Trip T1 departure to 19:00 → Manager's decision, alert resolves

### AC-04: Financial Record Integrity
1. Event base_currency = USD
2. Record Expense E1: 5,000 ILS, rate 3.5 ILS/USD, source=MANUAL
3. Verify: original_amount=5000, original_currency=ILS, exchange_rate=3.5, base_amount=1428.57 (5000/3.5)
4. Record Payment P1 from Person A: 500 USD
5. Verify: amount=500, currency=USD, base_amount=500
6. Verify only individual converted amounts and non-allocated event totals are shown; no participant balance is calculated
7. Change event base_currency → does NOT change stored exchange rates or original amounts
8. Lock Expense E1 (is_locked=TRUE) → base_amount preserved even if rate could be recalculated

### AC-05: Task Lifecycle & Overdue Detection
1. Create Task T1, due tomorrow, status=NEW
2. Advance device time past due date
3. Open Control Center → OVERDUE_TASK alert for T1 appears
4. Open Today View → T1 appears in overdue section
5. Complete T1 (status=COMPLETED, completed_at_utc set)
6. Verify OVERDUE_TASK alert auto-resolves
7. Verify T1 no longer in Today overdue, no longer in Control Center alerts

### AC-06: Soft Delete & Restore
1. Create Person P1 with accommodation assignment and trip assignment
2. Soft-delete Person P1 (is_deleted=TRUE)
3. Verify P1 not visible in default person list
4. Verify P1's AccommodationAssignment and TripPassenger records still exist (not deleted)
5. Verify related alerts generated (orphaned assignments)
6. Restore Person P1 (is_deleted=FALSE)
7. Verify P1 visible again
8. Verify assignments still intact
9. Verify orphan alerts auto-resolve

### AC-07: Backup & Restore Safety
1. Create event with representative data
2. Create backup → verify backup file created
3. Corrupt backup file (truncate or modify bytes)
4. Attempt restore from corrupted backup → FAIL with clear error
5. Verify current database completely intact, all data accessible
6. Create valid backup
7. Restore from valid backup → SUCCESS
8. Verify all data matches backup state

### AC-08: Offline Operation
1. Enable airplane mode / disable all network
2. Create event, add people, create flights, assign transport, assign accommodation
3. Edit records, search, view Control Center, view Today
4. Force-close app
5. Reopen app (still offline)
6. Verify all data persisted correctly
7. Verify all views functional
8. Verify search works
9. Verify rule evaluation works

### AC-09: Language Switching
1. Set interface language to Hebrew
2. Verify RTL layout throughout app
3. Enter person name in English: 'John Smith'
4. Enter hebrew_first_name: 'יוחנן'
5. Switch interface language to English
6. Verify LTR layout throughout app
7. Verify stored names unchanged: first_name='John Smith', hebrew_first_name='יוחנן'
8. Verify mixed-direction content displays correctly

### AC-10: Event Isolation
1. Create Event A and Event B
2. Create Person 'David Cohen' in Event A
3. Create Person 'David Cohen' in Event B (same name, different record)
4. Search 'David Cohen' in Event A → only Event A's David Cohen
5. Create Task in Event A → not visible in Event B
6. Create AccommodationAssignment in Event B → not visible in Event A
7. Verify Control Center shows only active event's data
8. Verify no cross-event relationship can be created

### AC-11: Data Migration
1. Create database with schema version N containing representative data
2. Deploy app version expecting schema N+1
3. App detects version mismatch, creates pre-migration backup
4. Migration executes, transforms schema
5. Verify all data preserved and accessible
6. Verify relationships intact
7. Verify schema version updated to N+1
8. (Failure scenario) Simulate migration failure → verify pre-migration backup restores successfully

### AC-12: Crash Recovery
1. Begin a multi-record operation (e.g., assign 5 people to a trip)
2. Simulate crash after 3 assignments committed
3. Restart application
4. Verify: either all 5 assignments exist OR only the individually committed ones exist
5. Verify no partial/corrupted records
6. Verify database integrity check passes
7. Verify all existing data accessible
