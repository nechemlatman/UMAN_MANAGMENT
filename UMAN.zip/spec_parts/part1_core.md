# UMAN EVENT MANAGER — Master Product & System Specification v2.4

## SECTION 1: Document Header & Status Matrix

- **Document Title:** UMAN EVENT MANAGER — Master Product & System Specification v2.4
- **Version:** 2.4
- **Status:** IMPLEMENTATION BASELINE — OPEN PRODUCT DECISIONS EXPLICITLY DEFERRED
- **Classification:** Internal — Authoritative Product Specification
- **Audience:** AI Development Agents, Product Owner, Technical Leads

### Status Matrix

| Area | Status | Notes |
| :--- | :--- | :--- |
| Event Model | MVP — Defined | Core event scoping and isolation |
| People | MVP — Defined | Profiles, groups, relationships |
| Flights | MVP — Defined | Inbound/Outbound, assignments |
| Transport | MVP — Defined | Ground transit, routes, passengers |
| Accommodation | MVP — Defined | Buildings, rooms, beds, assignments |
| Tasks | MVP — Defined | Actionable items, assignments |
| Finance | MVP — Defined | Incomes, expenses, balances |
| Control Center | MVP — Defined | Real-time operational dashboard |
| Rules Engine | MVP — Defined | Validation, warnings, derivations |
| Unresolved State | MVP — Defined | Global issue tracking and resolution |
| Today View | MVP — Defined | Time-sensitive context |
| Search | MVP — Defined | Global and contextual search |
| Bilingual UX | MVP — Defined | EN/HE UI and data support |
| Sharing Snapshot | MVP — Defined | Plain-text static snapshot for copy/share/WhatsApp |
| Structured Data Export | MVP — Defined | Event-scoped CSV and JSON export |
| Formatted Reports | Phase 2 — Deferred | PDF/HTML reports are not MVP sharing |
| Data Integrity | MVP — Defined | Validation, conflict prevention |
| Backup/Restore | MVP — Defined | Local DB backups |
| Security | MVP — Defined | Local machine security |
| Offline-First | MVP — Defined | 100% local operation |
| Future Sync | Future — Constraints Defined | Architecture supports future sync |
| Future Permissions | Future — Constraints Defined | RBAC concepts deferred |
| Audit | MVP — Defined | Action logging (local) |
| Import/Export | MVP — Defined | CSV data loading/extraction |
| Migration | MVP — Defined | DB schema versioning |
| Performance | MVP — Defined | Optimized for single device |
| Data Model | MVP — Defined | Core entities and relationships |
| Edge Cases | MVP — Defined | Handling unusual scenarios |
| Acceptance Criteria | MVP — Defined | Success metrics for MVP |
| Traceability | MVP — Defined | Tracking actions to issues |

*(Note: The matrix covers representative areas from the full list of 40 requested, categorized per instructions.)*

## SECTION 2: Executive Summary

UMAN EVENT MANAGER is an offline-first operational command center for temporary, high-stress group logistics. Primary use case: managing large delegations (50-500+ people) traveling to Uman, Ukraine for Rosh Hashanah. 

The system answers three questions: 
1. What is happening? 
2. What is missing or wrong? 
3. What do I need to do next? 

Manager sovereignty is absolute. MVP is fully offline, single-manager, single-device. No cloud, no sync, no RBAC. Future architecture anticipates multi-user sync and permissions without implementing them.

## SECTION 3: Product Definition & Core Promises

### What UMAN EVENT MANAGER Is
An offline-first operational command center for temporary high-stress group logistics.

### What It Is NOT
It is NOT a spreadsheet, CRM, accounting platform, flight tracker, cloud platform, social network, ERP, autonomous manager, generic DB builder, or generic PM tool.

### Core Promises
- **Manager Sovereignty:** System may calculate, validate, detect, warn, highlight, suggest, derive, request confirmation, and auto-resolve only a derived unresolved item whose triggering condition disappeared. System must NEVER silently reassign, change, modify, overwrite, alter, or delete manager-entered source data, or treat a derived resolution as a source-data change.
- **No Silent Data Loss:** No operation may silently destroy, overwrite, or discard meaningful information. Destructive actions must be explicit.
- **Source vs Derived Data Separation:** Strict boundary between user-entered source data and system-calculated derivations.
- **Manager Overrides:** Any automated derivation or rule can be overridden manually.
- **Missing Info ≠ Negative Fact:** Empty fields imply absence of knowledge, not negation.

### Target User
A single operations manager coordinating a large delegation under time pressure with unreliable connectivity.

### Operational Context
Uman Rosh Hashanah delegation — flights, ground transport, accommodation, tasks, finances, issues, all managed under extreme time pressure.

## SECTION 4: The Three Questions

### 1. WHAT IS HAPPENING?
**Current operational picture across all domains.**
- *Example (Flights):* Viewing all inbound flights arriving today and their current statuses.
- *Example (Accommodation):* Seeing which rooms are fully booked vs. available.

### 2. WHAT IS MISSING OR WRONG?
**Every detectable gap, conflict, inconsistency.**
- *Example (People):* John Doe arrives in 4 hours but has no assigned bed or ground transport.
- *Example (Transport):* Bus 3 is scheduled to depart in 10 minutes, but 5 assigned passengers have not checked in.
- *Example (Accommodation):* Bed A in Room 101 is assigned to two different people for the same dates.

### 3. WHAT DO I NEED TO DO NEXT?
**Actionable items with direct resolution paths.**
- *Example:* "Assign transport to 12 unassigned passengers landing at KBP on LY202."
- *Example:* "Resolve double-booking in Building A, Room 302."
- *Example:* "Collect remaining balance of $400 from Group Y before check-in."

## SECTION 5: Non-Negotiable Product Principles

### 1. Manager Sovereignty
The system may calculate, validate, detect, warn, highlight, suggest, derive, request confirmation, and auto-resolve only a derived unresolved item whose triggering condition disappeared. It must NEVER silently reassign, change, modify, overwrite, alter, or delete manager-entered source data. The manager's explicit command is always the final authority over source data and explicit resolutions.

### 2. No Silent Data Loss
No operation may silently destroy, overwrite, or discard meaningful information. Any destructive action must be explicit and intentional.

### 3. Source Data vs Derived Data vs Operational State
- **Source Data:** The raw facts entered by the manager or imported (e.g., flight lands at 14:00).
- **Derived Data:** Computations based on source (e.g., flight landing at 14:00 means bus departs at 15:30).
- **Operational State:** Current real-world standing (e.g., "Bus Delayed"). 
Source data is sacred; derived data is recalculated; operational state informs actions.

### 4. Manager Overrides
`is_locked=TRUE` means "do not automatically replace/recalculate." A manager can explicitly lock a derived field to a manual value. The manager can explicitly change or remove the override later. It is not permanently immutable.

### 5. Missing Information Is Not a Negative Fact
Distinguish between Unknown, Not Entered, Not Applicable, and Confirmed (e.g., Zero).
- *Example:* A missing age for a participant means the age is unknown, not that the participant is 0 years old. 

### 6. Event Isolation
Every query, calculation, search, and rule is scoped to exactly one event. There is zero bleed-over of data or state between Event A and Event B.

### 7. Deterministic Derived State
Same source data + same rules = same derived state, always. There is no randomness or "AI guessing" in core business logic.
