## SECTION 24: Data Integrity & Record Lifecycle

Distinct operations — each has different semantics:

| Operation | Meaning | Data Preserved? | Reversible? | Example |
|---|---|---|---|---|
| Delete (soft) | Mark record as logically removed | Yes (is_deleted=TRUE, deleted_at_utc=TIMESTAMP) | Yes (restore) | Remove a person added by mistake |
| Archive | Make record historical/inactive | Yes | Manager decision | Event after closeout |
| Cancel | Mark planned operation as cancelled | Yes (status=CANCELLED) | Manager can reactivate | Cancel a trip |
| Unassign | Remove a relationship, not the entity | Both entities preserved | Re-assignable | Remove person from sleeping place |
| Resolve | Close a derived/operational condition | Condition record preserved | Can reopen if condition recurs | Resolve apartment issue |
| Restore | Reactivate a soft-deleted record | Yes | N/A | Restore accidentally deleted person |

Rules:
- No operation may silently orphan important relationships.
- Atomic operations: where multiple records must change together, the operation must be atomic (all succeed or all fail).
- Cascade behavior: soft-deleting a parent does NOT auto-delete children. Children retain their own lifecycle. The system surfaces orphaned relationships as alerts.
- Referential integrity: FK relationships enforced. Cannot create a TripPassenger referencing a non-existent Person.

## SECTION 25: Backup, Restore & Recovery

**AEAD Authenticated Backup Format**:
Backups are packaged into an authenticated envelope using **AES-256-GCM** (or HMAC-SHA256 authenticated header):
- **Header**: Version, format identifier, KDF parameters (salt, iterations/memory cost), nonce/IV, authentication tag (MAC).
- **Encrypted Payload**: Database snapshot, schema version, audit metadata, application configuration.

**Backup Process**:
1. Manager initiates backup.
2. System prepares a consistent local SQLite database snapshot.
3. Passphrase passed to `SecurityKeyService` to derive a 256-bit encryption key.
4. Encrypt snapshot payload using AES-256-GCM AEAD into the backup archive envelope.
5. Write backup file to manager-selected local storage.
6. Confirm success to manager.

**Restore Process & Workspace Isolation**:
1. Manager selects backup file.
2. Read header and derive encryption key via `SecurityKeyService`.
3. **AEAD Authentication**: Verify MAC tag in memory *before* extracting contents. If authentication fails (wrong passphrase or tampered file), abort immediately without touching temporary storage or active database.
4. **Safe Temporary Workspace**: Decrypt archive into an isolated temporary workspace directory. Validate all file paths to strictly reject path traversal exploits (e.g., Zip-Slip attempts).
5. Run SQLite `PRAGMA quick_check;` and schema version compatibility verification.
6. Warn manager: "This will replace ALL current data." Manager explicitly confirms.
7. Create automatic pre-restore backup of the active database.
8. Perform **Atomic Database File Replacement**.
9. Reopen database and verify schema integrity.
10. Confirm recovery success to manager.

**Failure Handling**:
- Interrupted restore / crash: Detect pre-restore backup on restart and prompt manager to restore active state cleanly.
- Corrupted file / bad passphrase: Rejected at header validation stage; active database remains untouched.

## SECTION 26: Security & Privacy

**Key Management & Platform Storage**:
- **Passphrase KDF**: Manager passphrase is never stored in plaintext and never used directly as SQLite PRAGMA string. Derived into a 256-bit key using an approved password KDF (`SecurityKeyService` via Argon2id or PBKDF2 with configurable security policy).
- **Secure Storage**: Encryption keys held in memory during active session and stored securely via `SecurityStorageService` utilizing platform secure hardware keychains (Android Keystore / iOS Keychain).
- **Zero Diagnostics Material**: Passphrases, derived keys, and plaintext PII are strictly prohibited from appearing in debug logs, crash reports, or diagnostic exports.
- **Offline Data at Rest**: All SQLite database tables encrypted at rest with the single Drift-native encrypted SQLite execution path selected in the Technical Specification. Phase 1 must verify the encryption cipher at runtime before any write; it must never fall back to plaintext SQLite.
- Passphrase strength: minimum requirements configurable but enforced (minimum length)


## SECTION 27: Offline-First Architecture

Core principle: ALL MVP functionality works without network access.

No MVP workflow depends on:
- Cloud APIs
- Remote authentication
- Remote database
- Live flight APIs
- Remote sync
- CDN or remote assets
- External services

Conceptual architecture layers:
1. Presentation Layer: UI components, screens, navigation. No business logic.
2. Application Layer: Use cases, orchestration, transaction management. Coordinates domain operations.
3. Domain Layer: Entities, value objects, domain rules, business logic. Pure domain. No infrastructure dependencies.
4. Repository Interfaces: Abstract data access. Defined in domain layer. Implemented in infrastructure.
5. Local Data Source: encrypted SQLite database. File system. Local encrypted storage. The precise Drift executor, cipher build, and platform checks are normative in Technical Specification v1.1.

Business rules MUST NOT live inside UI widgets.
Domain layer MUST NOT depend on infrastructure layer.
Repository interfaces MUST be abstract (enabling future remote implementation without domain changes).

Data flow: UI → Use Case → Domain Logic → Repository Interface → Local Data Source

Network-optional features (future): flight data import, exchange rate import, cloud sync. These MUST be additive, never required.

## SECTION 28: Future Synchronization Constraints

MVP does NOT implement synchronization. However, the architecture MUST support future sync through these structural requirements:

- Stable UUIDv4 identities for all entities (no auto-increment primary keys)
- Event scoping (natural partition boundary)
- UTC timestamps for all temporal data (created_at_utc, updated_at_utc)
- Soft-delete with tombstone semantics (is_deleted, never hard-delete in normal operation)
- Repository abstraction (interface-based data access, swappable implementations)
- Identifiable relationships (explicit FK relationships, not implicit)
- Deterministic domain rules (same input → same output on any device)
- Preservation of source information (original values always retained)
- Conflict-detectable changes (updated_at_utc enables last-write-wins; future: vector clocks)
- Audit readiness (structural support for change tracking)

Future sync will use entity-specific conflict semantics:
- Person name conflict: present both versions to manager
- Accommodation assignment conflict: detect overlap, surface alert
- Financial record conflict: never auto-merge, always present to manager
- Task status conflict: last-write-wins with notification

Do NOT implement in MVP:
- CRDTs, Event Sourcing, version vectors, distributed state engines
- Sync UI, conflict resolution UI
- Remote data source implementations

## SECTION 29: Future Multi-User & Permissions Constraints

Future architecture anticipates:
- Multiple managers per event
- Role-based access: Full Manager, Limited Manager, Read-Only Viewer
- Action-level permissions (who can create/edit/delete which entities)
- Field-level permissions (who can see passport numbers, financial data)
- Invitations (manager invites other users to event)
- Synchronized shared state with conflict handling

MVP constraints:
- Single manager, single device
- No user accounts
- No authentication beyond passphrase for encryption
- No RBAC UI
- No permission checks in business logic (all operations permitted to the single manager)

Architectural preparation:
- Use case layer provides natural permission injection point
- Entity ownership (created_by) can be added without schema redesign
- Event scoping enables per-event permission boundaries
- Repository abstraction supports permission-filtered queries

Do NOT distribute premature permission logic throughout UI components.

## SECTION 30: Audit Readiness

MVP audit readiness: structural only. The schema supports audit records but comprehensive audit logging is a future enhancement.

AuditEntry (conceptual): id (UUIDv4), event_id (FK), entity_type, entity_id (UUIDv4), action (CREATE/UPDATE/DELETE/RESTORE/ASSIGN/UNASSIGN/STATUS_CHANGE), timestamp_utc, changes_json (nullable, field-level before/after), actor_id (nullable, future multi-user), notes

MVP behavior:
- Schema includes AuditEntry table
- Critical operations MAY write audit entries (creation, deletion, financial changes)
- Comprehensive field-level change tracking is deferred
- Audit entries are append-only (never modified, never deleted)
- Audit data is included in backups

Future behavior:
- Full change tracking for all entities
- Actor identification
- Audit log viewer UI
- Audit export

## SECTION 31: Data Import & Export

Import:
- Supported: structured data import (e.g., participant list from CSV/Excel)
- Event-scoped: imported data belongs to the target event
- Behavior: never silently overwrite existing records
- Duplicate detection: warn on potential duplicates (name + phone match)
- Manager reviews and confirms each import batch
- Mapping: manager maps import columns to entity fields
- Validation: invalid records flagged, not silently skipped
- Atomic: import batch succeeds or fails as a unit
- Recovery: interrupted import leaves no partial state

Export:
- Structured export of event data (CSV, JSON)
- Filtered export (specific entities, date ranges)
- Export includes source data only (not derived state)
- Export is event-scoped
- Export does not modify source data

Not in MVP:
- Generic integration platform
- API-based import/export
- Automated recurring imports
- Remote data source connections

## SECTION 32: Data Migration & Versioning

Schema version: integer, monotonically increasing, stored in database metadata.

Migration requirements:
- Schema version identifiable at runtime
- Migrations are deterministic and repeatable
- Migrations preserve all user data
- Failed migration does NOT destroy existing database
- Automatic pre-migration backup for destructive migrations
- Old records remain interpretable after migration
- Migration behavior is testable (automated migration tests)
- Forward-only migrations (no rollback, but backup enables recovery)

Migration process:
1. App launches, reads current schema version
2. Compares to expected version
3. If migration needed: create automatic backup
4. Execute migration steps sequentially
5. Verify data integrity after migration
6. Update schema version
7. If any step fails: restore from pre-migration backup, report error

Version compatibility:
- App version N can read schema version N and migrate from N-k (reasonable range)
- App warns if schema version is newer than expected (future app version created the data)
- Backup files include schema version for compatibility checking
