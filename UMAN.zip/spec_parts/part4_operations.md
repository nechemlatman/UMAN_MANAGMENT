## SECTION 17: Control Center

The Control Center is the primary operational dashboard. It is NOT a passive statistics page.

**Purpose**: Give the manager an immediate, prioritized operational picture.

**Content (prioritized)**:
1. Critical unresolved items (CRITICAL priority)
2. High-priority unresolved items
3. Overdue tasks
4. Today's arrivals and departures
5. Active transport gaps (passengers without transport)
6. Accommodation gaps (persons without sleeping place)
7. Unresolved apartment issues
8. Vehicle overcapacity alerts
9. Financial obligations (unpaid balances)
10. Approaching deadlines (tasks due within configurable window)
11. Event lifecycle status
12. Summary counts (people, flights, trips, assignments, tasks)

Every actionable item must have a direct tap/navigation path to the relevant entity and resolution workflow.

Control Center must trigger time-dependent rule evaluation on open.

Control Center must not become a second source of truth. It reads from derived state only.

## SECTION 18: Reactive Domain Rules Engine

**Purpose**: Detect, calculate, and surface operational conditions from source data.

**Properties**:
- **Deterministic**: same inputs → same outputs.
- **Deterministic Alert Identity**: `deterministicAlertId = SHA-256(canonical(ruleCode, entityType, entityId, scopeKey))`. Same rule + same entity + same scope yields the exact same alert ID. Re-evaluation never creates duplicate alerts, and existing manager acknowledgment states remain attached to the logical alert. Random UUIDs are forbidden for logical alert identity.
- **Domain-scoped**: rules belong to specific operational domains.
- **Testable**: every rule is tested with pure Dart unit tests against known inputs.
- **Idempotent**: repeated evaluation produces identical results with zero duplicate active records.
- **Explainable**: each rule describes what it detected, why, and provides direct resolution options.
- **Lightweight**: pure Dart implementation with zero external framework dependencies.

**Rule Domains & Approved Rule Codes**:

| Domain | Prefix | Rule Code | Severity | Description / Trigger Condition |
|---|---|---|---|---|
| PEOPLE | PPL | PERSON_WITHOUT_SLEEPING_PLACE | HIGH | Person has no active accommodation assignment for event dates |
| PEOPLE | PPL | PERSON_WITHOUT_TRANSPORT | HIGH | Person has no trip passenger assignment for inbound/outbound travel |
| PEOPLE | PPL | PASSPORT_EXPIRY_RISK | HIGH | `Person.passport_expiration_date` is within 6 months of event departure date (`Event.start_date`) |
| FLIGHTS | FLT | FLIGHT_DELAY_IMPACT | MEDIUM | Flight delayed; advisory issued for manager to review transport alignment |
| FLIGHTS | FLT | FLIGHT_CANCELLED | CRITICAL | Flight cancelled; passengers and transport require immediate manual reallocation |
| FLIGHTS | FLT | DUPLICATE_FLIGHT_ASSIGNMENT | HIGH | Person assigned to multiple inbound or multiple outbound flights with overlapping or within-12h schedules |
| FLIGHTS | FLT | FLIGHT_MISSING_INFO | MEDIUM | Required schedule or airport information is absent, so dependent transport assessment is degraded |
| TRANSPORT | TRN | VEHICLE_OVER_CAPACITY | HIGH | Assigned passengers on a trip exceed `Vehicle.capacity` |
| TRANSPORT | TRN | TRN_NO_DRIVER | HIGH | `Trip` scheduled within 2 hours of departure (`scheduled_departure_utc`) without an assigned `Driver` |
| TRANSPORT | TRN | UNLINKED_FLIGHT_ARRIVAL | MEDIUM | Inbound `FlightPassenger` arriving without a `TripPassenger` assignment on a trip departing within 3 hours of flight arrival |
| TRANSPORT | TRN | TRIP_VEHICLE_UNAVAILABLE | HIGH | A non-cancelled trip references a vehicle whose status is MAINTENANCE or UNAVAILABLE |
| ACCOMMODATION | ACC | ACCOMMODATION_OVERLAP | HIGH | Two active assignments for the same `SleepingPlace` overlap in date range |
| ACCOMMODATION | ACC | OVERFLOW_ROOM_CAPACITY | HIGH | Active assignments for a `Room` on any date exceed total active `SleepingPlace` bed count in that room |
| TASKS | TSK | OVERDUE_TASK | HIGH | Task incomplete and past `due_date_utc` |
| APARTMENT_ISSUES | APT | UNRESOLVED_APARTMENT_ISSUE | MEDIUM | Apartment issue logged with status OPEN or IN_PROGRESS |
| FINANCE | FIN | UNPAID_BALANCE | MEDIUM | Person or group has outstanding balance prior to event completion |
| FINANCE | FIN | EXPENSE_WITHOUT_RATE | MEDIUM | A non-base-currency expense or payment lacks the recorded exchange rate needed for conversion |
| PEOPLE | PPL | PERSON_MISSING_CRITICAL_INFO | MEDIUM | A manager-selected required travel-contact field is absent; the required-field policy is event-scoped |
| OPERATIONS | OPS | EVENT_LIFECYCLE_TRANSITION_NEEDED | INFO | Event stage transition criteria met |

**Trigger & Evaluation Model**:
- **Full Evaluation**: Executed on app startup integrity check, manual audit, data recovery, or explicit full refresh.
- **Scoped Evaluation**: Executed during normal CRUD operations. The system identifies the affected scope (e.g., accommodation scope, transport scope) and re-evaluates only relevant rules and queries. Full-database loading is forbidden for ordinary CRUD-triggered evaluations.
- **Hybrid Scheduling Policy**: High-priority isolated changes trigger immediate scoped evaluation. Bursts of related edits trigger a debounced/throttled evaluation (target 300ms initial parameter) to coalesce changes before updating unresolved state and notifying UI.

**Rule Output**: Each rule evaluation produces zero or more deterministic `UnresolvedItem` records (or auto-resolves obsolete items).

## SECTION 19: Unresolved Operational State

`UnresolvedItem`: id (SHA-256 deterministic hash, PK), event_id (FK), rule_code, entity_type, entity_id (UUIDv4), scope_key (nullable composite key), severity (CRITICAL/HIGH/MEDIUM/LOW/INFO), title, description, status (DETECTED/ACKNOWLEDGED/RESOLVED/DISMISSED), detected_at_utc, acknowledged_at_utc, resolved_at_utc, dismissed_at_utc, dismissed_reason, auto_resolved (BOOLEAN), resolution_notes, created_at_utc, updated_at_utc, deleted_at_utc (nullable), version (INT, default 1), last_modified_by_device_id (nullable string)

`UnresolvedItem` is NEVER source data. It is derived operational state.

The source entity remains authoritative. `UnresolvedItem` is a lens into source data.

**Deterministic Identity Algorithm**:
- Canonical string: `rule_code + "|" + entity_type + "|" + entity_id + "|" + (scope_key ?? "")`
- `id` = `sha256(canonical_string).toHex()`
- Prevents duplicate active items across evaluations and preserves manager acknowledgment state.

**Control Center Triage & Interaction Safeguards**:
- **Triage**: Control Center supports grouping alerts by Location (Building/Airport), Entity, or Rule Type, and filtering by Severity.
- **Direct Action Deep-Links**: Alerts contain direct action paths (e.g., "Assign Bed", "Assign Driver", "Reassign Bus", "Review Passenger", "Open Flight").
- **Interaction Safeguards**: Bulk dismissal is permitted only for non-critical informational advisories. Critical and High severity alerts require explicit individual manager interaction.

**Lifecycle and deterministic upsert semantics**:
- **DETECTED**: a newly observed condition. Set `detected_at_utc`, `created_at_utc`, and `updated_at_utc` to the evaluation time; set `auto_resolved=FALSE`, with all resolution timestamps null.
- **ACKNOWLEDGED**: manager has seen it; it remains active. Re-evaluation of the same active identity preserves status, acknowledgment fields, and the original `detected_at_utc`.
- **RESOLVED**: condition disappeared during evaluation (`auto_resolved=TRUE`) or a manager explicitly resolved it (`auto_resolved=FALSE`). Set `resolved_at_utc` only on that transition.
- **DISMISSED**: manager explicitly dismissed it. The default `OperationalRule.re_trigger_after_dismiss` is FALSE; while false, a still-present or recurring condition does not reopen that logical item. If a manager enables it, a later recurrence reopens the same deterministic ID as DETECTED with a new detection timestamp.
- For every scoped evaluation, upsert the returned deterministic IDs and compare them only with active items in that same event and rule scope. Any previously active DETECTED/ACKNOWLEDGED item in that scope that is absent from the new result transitions once to RESOLVED with `auto_resolved=TRUE`. Do not mark a newly detected issue auto-resolved, and do not resolve a still-returned item.
- Pair and multi-entity scopes must be canonical. For an unordered pair, `scope_key = sort([id1, id2]).join('|')`; never use iteration order.

## SECTION 20: Today View

Today is a time-oriented operational view showing what matters RIGHT NOW.

**Content**:
- Today's trips (departures, arrivals)
- Today's flight arrivals and departures
- Overdue tasks
- Tasks due today
- Accommodation changes today (check-ins, check-outs)
- Active apartment issues
- Time-sensitive unresolved items
- Important financial actions due today

Today must NEVER become a second source of truth. It reads from the same domain data as everything else.

**Time reference**: 'Today' is determined by the device's local date. Stored UTC times are converted for display.

Today triggers time-dependent rule evaluation on open.

## SECTION 21: Universal Search

Search operates across the ACTIVE event only. Event isolation is absolute.

**Searchable content**:
- Person names (first, last, Hebrew, English)
- Phone numbers (normalized matching)
- Flight numbers
- Airline names
- Airport codes
- Apartment names and addresses
- Room names
- Driver names
- Vehicle identifiers and license plates
- Task titles and descriptions
- Apartment issue titles
- Notes fields
- Expense descriptions and categories
- Payment references

**Search requirements**:
- Hebrew text support
- English text support
- Mixed Hebrew/English queries
- Partial matching
- Case-insensitive for Latin text
- Diacritic-insensitive where practical
- Results grouped by entity type
- Soft-deleted records excluded from default search (optionally includable)
- Performance: < 80ms on benchmark dataset

## SECTION 22: Bilingual UX — Hebrew RTL / English LTR & Operational Ergonomics

**Bilingual & BIDI Requirements**:
- Full Hebrew RTL interface.
- Full English LTR interface.
- Runtime language switching without app restart.
- **Centralized BIDI Text Formatting Helper**: Mixed-directional strings (Hebrew names, English flight numbers, phone numbers, passport IDs, dates, room numbers, bus codes) MUST be processed via a centralized formatting abstraction (`BidiTextFormatter`) utilizing Unicode directional isolation markers (`\u200E` LRM / `\u200F` RLM) or Flutter bidi utilities. Manual, inline insertion of raw directional unicode control characters across UI widgets is forbidden.
- Logical directional layout: `Start`/`End`, `Leading`/`Trailing` padding and alignment — NOT hard-coded `Left`/`Right`.
- Changing interface language MUST NEVER alter stored source data.
- User-entered Hebrew text preserved exactly (no transliteration, no normalization).
- User-entered English text preserved exactly.
- All system labels, messages, and navigation bilingual.
- Date and number formatting localized per locale.
- Universal Search handles both Hebrew and English simultaneously.

**High-Stress Outdoor & Low-Light Operational UX**:
- **High-Contrast Dark Theme**: Native support for high-contrast dark theme for low-light operations (e.g., unlit bus terminals or late-night flights) and high-visibility light theme for direct outdoor Ukrainian sunlight.
- **Legibility & Touch Targets**: Touch targets must meet minimum 48x48dp dimensions; typography optimized for rapid scanning under operational stress.
- **Multi-Modal Severity Communication**: Severity states (CRITICAL, HIGH, MEDIUM) must be communicated through text labels, iconography, typography, and visual structure — NEVER by color alone.
- **Haptic Feedback**: Optional tactile haptic feedback on critical operational warnings and destructive confirmations.

## SECTION 23: External Sharing Snapshots & PII Sanitization

The system generates static, point-in-time read-only snapshots for sharing via WhatsApp, SMS, email, or local file export.

**Snapshot Types**:
- Transport manifest (trip route, departure time, driver, vehicle, assigned passengers)
- Accommodation manifest (building, room, sleeping place, dates, assigned participants)
- Arrival manifest (expected arrivals by date/flight)
- Departure manifest (expected departures by date/flight)
- Task list (assigned tasks with status)
- Participant contact list
- Operational summary
- Financial summary (configurable detail level)

**PII Sanitization & Masking Policy**:
- **Default Behavior (`PII MASKING = ON`)**: Sensitive personal identification data is automatically masked in generated external text snapshots:
  - Passport numbers: masked to last 4 digits (e.g., `****1234`)
  - Phone numbers: masked to last 4 digits (e.g., `***-***-1234`)
- **Operational Necessity Exception**: Full participant names, room numbers, and trip details are retained unmasked as they are operationally necessary for flight check-in and vehicle boarding.
- **Explicit Unmasked Export**: The manager can trigger an explicit user action: **"Export Full Details (Unmasked)"**. The system must display a privacy confirmation warning explaining the exposure before generating an unmasked snapshot.

**Snapshot Properties**:
- Contains event name and UTC/local generation timestamp.
- Clearly identifiable header marking it as a static point-in-time document, NOT live data.
- Plain text formatted for immediate readability on WhatsApp and mobile messaging apps.
- Bilingual (Hebrew/English) format support.
- Creates no remote state, no cloud records, no external server calls.
